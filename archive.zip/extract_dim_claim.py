import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.sql.functions import *
from awsglue.dynamicframe import DynamicFrame
from datetime import datetime, date
from pytz import timezone
import pandas as pd
import pg8000
import boto3
import json

## @params: [JOB_NAME]
args = getResolvedOptions(sys.argv, ['JOB_NAME','raw_stage_bucket','raw_stage_database','edw_hostip','edw_hostport','edw_databasename','edw_srcschema','metarep_hostip','metarep_hostport','metarep_databasename','metarep_srcschema','metarep_secret_name','edw_secret_name'])
raw_stage_bucket = args['raw_stage_bucket']
raw_stage_database = args['raw_stage_database']
edw_hostip = args['edw_hostip']
edw_hostport = args['edw_hostport']
edw_databasename =args['edw_databasename']
edw_srcschema = args['edw_srcschema']

metarep_hostip = args['metarep_hostip']
metarep_hostport = args['metarep_hostport']
metarep_databasename = args['metarep_databasename']
metarep_srcschema = args['metarep_srcschema']
raw_tablename="stage_dim_claim"

metarep_secret_name = args['metarep_secret_name']
edw_secret_name=args['edw_secret_name']

#Extract credentials from Secrets manager
client = boto3.client("secretsmanager", region_name="us-east-2")
aurora_creds=client.get_secret_value(SecretId=metarep_secret_name)
sqlserver_creds = client.get_secret_value(SecretId=edw_secret_name)
metarep_secret=aurora_creds['SecretString']
metarep_secret=json.loads(metarep_secret)
#Retrieve Aurora Database credentials
metarep_username = metarep_secret.get('username')
metarep_password = metarep_secret.get('password')

#Retrieve SqlServer Database credentials
sqlserver_secret=sqlserver_creds['SecretString']
sqlserver_secret=json.loads(sqlserver_secret)

edw_username = sqlserver_secret.get('username')
edw_password = sqlserver_secret.get('password')

args = getResolvedOptions(sys.argv, ['JOB_NAME'])
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args['JOB_NAME'], args)

#Create Connection to extract lastcreatetimestamp from etl control table
query_conn = pg8000.connect(
    database=metarep_databasename,
    user=metarep_username,
    password=metarep_password,
    host=metarep_hostip,
    port=metarep_hostport
)
read_control_table = """
select last_extract_time
    from metarep.etl_extract_state
    where table_name='stage_dim_claim'
    group by last_extract_time
"""
cur = query_conn.cursor()
cur.execute(read_control_table)
last_extract_time=str(cur.fetchone()[0])
cur.close()
query_conn.close()
job_start_time=datetime.now().strftime('%Y-%m-%d %H:%M:%S')


#Extract data from SQL server
extract_df = glueContext.read.format("jdbc").option("url","jdbc:sqlserver://"+edw_hostip+":"+edw_hostport+";databaseName="+edw_databasename+";").option("user",edw_username).option("password",edw_password).option("dbtable","(select * from "+edw_srcschema+".edwclaimdim where (createdate>'"+last_extract_time+"' or lastupdatedate>'"+last_extract_time+"' )) as edwclaimdim").option("driver","com.microsoft.sqlserver.jdbc.SQLServerDriver").load()
init_dynamicframe = DynamicFrame.fromDF(extract_df, glueContext, "init_dynamicframe")
applymapping1 = ApplyMapping.apply(frame = init_dynamicframe, mappings = [("indemnitypaid", "string", "indemnitypaid", "string"), ("claimfinaldispositiondate", "timestamp", "claimfinaldispositiondate", "timestamp"), ("createdate", "timestamp", "createdate", "timestamp"), ("legacycasenumber", "string", "legacycasenumber", "string"), ("result", "string", "result", "string"), ("servicedate", "timestamp", "servicedate", "timestamp"), ("claimlob", "string", "claimlob", "string"), ("gllosstype", "string", "gllosstype", "string"), ("coverage_fk", "long", "coverage_fk", "long"), ("batchid", "string", "batchid", "string"), ("policy_fk", "long", "policy_fk", "long"), ("losssubtype", "string", "losssubtype", "string"), ("claimcreateby", "string", "claimcreateby", "string"), ("coverage_nk", "long", "coverage_nk", "long"), ("lossdescription", "string", "lossdescription", "string"), ("policy_nk", "long", "policy_nk", "long"), ("legacycasenumber2", "string", "legacycasenumber2", "string"), ("treatmentdate", "timestamp", "treatmentdate", "timestamp"), ("claimcreatedate", "timestamp", "claimcreatedate", "timestamp"), ("punititivedamagesflag", "string", "punititivedamagesflag", "string"), ("lastupdateby", "string", "lastupdateby", "string"), ("case_nk", "long", "case_nk", "long"), ("claimcounty", "string", "claimcounty", "string"), ("createby", "string", "createby", "string"), ("reportdate", "timestamp", "reportdate", "timestamp"), ("claimstate", "string", "claimstate", "string"), ("claimfinaldispositioncode", "string", "claimfinaldispositioncode", "string"), ("currentrecordflag", "int", "currentrecordflag", "int"), ("claim_nk", "long", "claim_nk", "long"), ("treatement", "string", "treatement", "string"), ("specialtracking", "string", "specialtracking", "string"), ("claimupdatedate", "timestamp", "claimupdatedate", "timestamp"), ("claimcity", "string", "claimcity", "string"), ("consentflag", "string", "consentflag", "string"), ("claimcurrentstatus", "string", "claimcurrentstatus", "string"), ("primaryclaimflag", "string", "primaryclaimflag", "string"), ("claimlatestclosedate", "timestamp", "claimlatestclosedate", "timestamp"), ("allegation", "string", "allegation", "string"), ("case_fk", "long", "case_fk", "long"), ("condition", "string", "condition", "string"), ("claimnumber", "string", "claimnumber", "string"), ("claimfinaldisposition", "string", "claimfinaldisposition", "string"), ("agentofinsuredflag", "string", "agentofinsuredflag", "string"), ("risk_fk", "long", "risk_fk", "long"), ("claimupdateby", "string", "claimupdateby", "string"), ("enddate", "timestamp", "enddate", "timestamp"), ("claim_pk", "long", "claim_pk", "long"), ("claimlatestreopendate", "timestamp", "claimlatestreopendate", "timestamp"), ("claimfinaldispositiongroup", "string", "claimfinaldispositiongroup", "string"), ("losstype", "string", "losstype", "string"), ("claimfirstopendate", "timestamp", "claimfirstopendate", "timestamp"), ("sourcesystem", "string", "sourcesystem", "string"), ("risk_nk", "long", "risk_nk", "long"), ("claimcurrenttype", "string", "claimcurrenttype", "string"), ("lastupdatedate", "timestamp", "lastupdatedate", "timestamp")], transformation_ctx = "applymapping1")
resolvechoice2 = ResolveChoice.apply(frame = applymapping1, choice = "make_struct", transformation_ctx = "resolvechoice2")
dropnullfields3 = DropNullFields.apply(frame = resolvechoice2, transformation_ctx = "dropnullfields3")
#Extract max create timestamp from dataframe
temp_df=applymapping1.toDF().createOrReplaceTempView("stage_df")
 
max_extract_time_sf = spark.sql("SELECT max(maxdate)  from (select COALESCE(max(createdate),'"+last_extract_time+"' ) as maxdate FROM   stage_df union select COALESCE(max(lastupdatedate),'"+last_extract_time+"' ) as maxdate FROM   stage_df)a")

max_extract_time=str(max_extract_time_sf.first()[0])
if max_extract_time==last_extract_time:
    print('true')
else:
    print('false')

#Copy/Sink the data to S3
datasink1 = glueContext.write_dynamic_frame.from_options(frame = applymapping1, connection_type = "s3", connection_options = {"path": "s3://"+raw_stage_bucket+"/edw/"+raw_stage_database+"/"+raw_tablename+"/incremental_createtimestamp="+job_start_time+"/"}, format = "parquet", transformation_ctx = "datasink1")

#Connect to Aurora postgres db
config_port = 5432
update_conn = pg8000.connect(
    database=metarep_databasename,
    user=metarep_username,
    password=metarep_password,
    host=metarep_hostip,
    port=metarep_hostport
)
#Update extract flag=0 to indicate the extraction was completed successfully and
#set load_flag=0 to indicate the load is still pending for next glue job to pickup data from s3 bucket

update_control_table = "update metarep.etl_extract_state set job_start_time='"+job_start_time+"' ,extract_flag=1, load_flag=0 where table_name='stage_dim_claim';"
cur = update_conn.cursor()
cur.execute(update_control_table)
update_conn.commit()
cur.close()
update_conn.close()
job.commit()