# -*- coding: utf-8 -*-
"""
Created on Wed Apr 21 12:15:28 2021

@author: 600000703
"""

import os
import boto3
import json
import pyodbc
pyodbc.pooling = False
import pg8000
import time
import datetime


rds_secretsmanager = boto3.client("secretsmanager", region_name="us-east-2")
rds_secret_arn = os.environ['RDS_SECRET_ARN']
rds_db_name = os.environ['DB_NAME']
rds_db_host=os.environ['RDS_Endpoint']
rds_db_port=os.environ['RDS_PORT']
ts = time.time()
timestamp = datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d %H:%M:%S')

db_secret = "arn:aws:secretsmanager:us-east-2:252759991802:secret:medpro-prod-ds-edw-on-prem-sql-server-36XLDF"
db_secret = "arn:aws:secretsmanager:us-east-2:613640794830:secret:medpro-uat-ds-edw-on-prem-sql-server-x5lCXt"

db_server = "10.1.25.67"  #PRODSDB015.medpro.com
db_server = "10.2.26.54"  #UATSDB015.medpro.com

db_port = "1433"
db_server = db_server + "," + db_port

db_name = "MPG_STG_PROD"
db_name = "MPG_STG_UAT"

s3 = boto3.resource('s3')
secretsmanager = boto3.client("secretsmanager", region_name="us-east-2")
lambdaSession = boto3.Session()
region = lambdaSession.region_name

def make_conn():
    conn = None
    try:
        get_secret_value_response = secretsmanager.get_secret_value(
            SecretId=db_secret
        )
        secret = get_secret_value_response['SecretString']
        secret = json.loads(secret)
        db_user = secret.get('username')
        db_pass = secret.get('password')

        print("DB info:  ", db_server, db_name, db_user)
        print("drivers:  ", pyodbc.drivers())
        conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER='+db_server+';DATABASE='+db_name+';UID='+db_user+';PWD='+db_pass)

        print("Successfully established connection: ", conn)
    except Exception as e:
        print("I am unable to connect to the database: ", e)
        print("Exception: {}".format(e))
    return conn



def make_conn_pg800():
    conn_pg8000 = None
    try:
        get_secret_value_response = secretsmanager.get_secret_value(
            SecretId=rds_secret_arn
        )
        secret = get_secret_value_response['SecretString']
        secret = json.loads(secret)
        rds_db_user = secret.get('username')
        rds_db_pass = secret.get('password')
        conn_pg8000 = pg8000.connect(
            database=rds_db_name,
            user=rds_db_user,
            password=rds_db_pass,
            host=rds_db_host,
            port=rds_db_port
        )
        print("Successfully established connection")
    except:
        print("I am unable to connect to the database")
    return conn_pg8000
    
def call_rds_data_api_to_add(jobauditkey_pk, starttime, endtime, conn_pg8000):
    try:
        cursor = conn_pg8000.cursor()
        #jobauditkey_pk = int(jobauditkey_pk)
        lastupdateby = 'Batch_Job'
        Sql_insert_query = ("INSERT INTO metarep.daily_glue_trigger_log (jobauditkey_pk, starttime, endtime, lastupdateby, lastupdatedate) VALUES(%s, %s, %s, %s, %s)") 
        record  = (jobauditkey_pk, starttime, endtime, lastupdateby, timestamp)
        cursor.execute(Sql_insert_query , record)
        conn_pg8000.commit()
    except Exception as e:
        print('Insert Failed',e)



def runSelectQuery(conn):
    cursor = conn.cursor()
    sql = """
    SELECT top 1 JA.* FROM mpg_s2.ictJobAudit JA, mpg_s2.ictJobDim JD,  mpg_s2.ictDataSrcSysDim DS WHERE JA.JobKey_FK = JD.JobKey_PK AND JD.SourceSystem_FK= DS.SourceSystem_PK AND DS.DataSourceName='EDW_E2' AND JD.jobName ='wf_MPGEDW_E1_To_E2_CaseClaimSelfServe' AND JA.JobStatusDescription='SUCCEEDED' AND JA.startTime > cast(getDate()-10 AS Date) order by JA.EndTime desc;
    """
    cursor.execute(sql)
    tablist = list(cursor.fetchall())    
    cursor.close()
    del cursor
    conn.close()
    return tablist

def call_rds_data_api_select(conn_pg8000, received_jobauditkey_pk):
    try:
        cursor = conn_pg8000.cursor()
        select_sql = ("select * from metarep.daily_glue_trigger_log where jobauditkey_pk = %s")
        cursor.execute(select_sql, (received_jobauditkey_pk,))
        rows = cursor.fetchall()
        print('Total Row(s):', cursor.rowcount)
        return cursor.rowcount
    except Exception as e:
        print('Unable to select current day Records',e)
    finally:
        # closing database connection.
        if conn_pg8000:
            cursor.close()
            conn_pg8000.close()
            print("PostgreSQL connection is closed")

def lambda_handler(event, context):
    try:
        #print("event: {}".format(event))
        conn_pg8000 = make_conn_pg800()
        print(conn_pg8000)
        conn = make_conn()
        result = runSelectQuery(conn)
        if len(result):
            print(result[0][0], result[0][5], result[0][6])
            val = call_rds_data_api_select(conn_pg8000, str(result[0][0]))
            if val == 0:
                print("new entryand start step function and insert entry in log table")
                
                #call_rds_data_api_to_add(result[0][0], result[0][5], result[0][6], conn_pg8000)
            else:
                print("Already processed for the current date")
        else:
            print("Data Yet not Uploaded:  ", result,  result)
    except Exception as e:
        print("Failed to process Index files. Exception: {}".format(e))

# JobAuditKey_PK	JobKey_FK	SourceSystem_FK	SourceKey_FK	RunTime	StartTime	EndTime	NumberOfSrcRecordsProc	NumberOfTgtRecordsProc	CheckSumSrc	CheckSumTgt	NumberOfErrors	BatchId	JobStatusCode	JobStatusDescription

# resultt[0][0]   20690                                    --- JobAuditKey_PK
# resultt[0][1]    2241
# resultt[0][2]      22
# resultt[0][3]     320
# resultt[0][4]   12.967
# resultt[0][5]   datetime.datetime(2021, 4, 20, 11, 5, 8)  --- StartTime_edw 
# resultt[0][6]   datetime.datetime(2021, 4, 20, 11, 18, 6)  -- EndTime_edw
#           YOU WILL BE INSETING THIS                       --- EntryTime

# resultt         [(20690, 2241, 22, 320, 12.967, datetime.datetime(2021, 4, 20, 11, 5, 8), datetime.datetime(2021, 4, 20, 11, 18, 6), None, None, None, None, None, '25756', '1', 'SUCCEEDED')]
 
# if len(resultt):
# Check at aurora table (daily_glue_trigger_log) if resultt[-1][0] OR JobAuditKey_PK nubmer is already there

# IF YES  -- Donot do anything

# IF NO  -- 
# Trigger the Glue step function
# And Insert Line to Aurora Table (daily_glue_trigger_log)  with EntryTime


# daily_glue_trigger_log  -->  JobAuditKey_PK               StartTime	                              EndTime                                     TimeOfEntry 
#                               20690,                 datetime.datetime(2021, 4, 20, 11, 5, 8),   datetime.datetime(2021, 4, 20, 11, 18, 6)        time.now()

#drop table metarep.daily_glue_trigger_log;
#create table metarep.daily_glue_trigger_log(jobauditkey_pk bigint PRIMARY KEY, starttime timestamp without time zone, endtime timestamp without time zone, lastupdateby text, lastupdatedate timestamp without time zone)



'''
db_user:  svc_AWS_EDW_UAT
db_pass:  !Zb2CK9aRVjcE!T
db_name:   MPG_EDW_UAT
db_host:  10.2.26.54
db_port:  1433
'''