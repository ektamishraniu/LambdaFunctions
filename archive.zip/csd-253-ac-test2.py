import os, re
import io
import boto3
import botocore
import csv
from pathlib import Path, PurePath
import json, time
from datetime import datetime
import pyodbc

#db_secret=os.environ['RDS_SECRET_ARN']
#db_name=os.environ['RDS_DB_NAME']
#db_host=os.environ['RDS_Endpoint']
#db_port=os.environ['RDS_PORT']

db_secret = "arn:aws:secretsmanager:us-east-2:252759991802:secret:medpro-prod-ds-edw-on-prem-sql-server-36XLDF"
db_secret = "arn:aws:secretsmanager:us-east-2:613640794830:secret:medpro-uat-ds-edw-on-prem-sql-server-x5lCXt"

db_server = "10.1.25.67"  #PRODSDB015.medpro.com
db_server = "10.2.26.54"  #UATSDB015.medpro.com
#db_server = "10.2.26.44"  #DEVSDB015.medpro.com
db_port = "1433"

db_name = "MPG_STG_PROD"
db_name = "MPG_STG_UAT"
#db_name = "MPG_STG_DEV"

db_driver = '{ODBC Driver 17 for SQL Server}'
db_driver = '{SQL Server}'
        #db_user:  svc_AWS_EDW_UAT
        #db_pass:  !Zb2CK9aRVjcE!T
        #db_name:   MPG_EDW_UAT
        #db_host:  10.2.26.54
        #db_port:  1433
        
s3 = boto3.resource('s3')
secretsmanager = boto3.client("secretsmanager", region_name="us-east-2")
lambdaSession = boto3.Session()
region = lambdaSession.region_name

def make_conn():
    conn = None
    try:
        get_secret_value_response = secretsmanager.get_secret_value(
            SecretId=db_secret
        )
        secret = get_secret_value_response['SecretString']
        secret = json.loads(secret)
        db_user = secret.get('username')
        db_pass = secret.get('password')

        print("db_user: ", db_user)
        print("db_pass: ", db_pass)
        print("db_name:  ", db_name)
        print("db_host: ", db_server)
        print("db_port: ", db_port)
        
        
        #conn = pyodbc.connect('DRIVER='+ db_driver + ';PORT=' + db_port + ';SERVER=' + db_driver + 'DATABASE=' + db_name + ';UID=' + db_user + ';PWD=' + db_pass)
        conn = pyodbc.connect(UID='svc_AWS_EDW_UAT',PWD='!Zb2CK9aRVjcE!T', DRIVER='{SQL Server}',SERVER='10.2.26.54',DATABASE='MPG_STG_UAT')
        
        print("Successfully established connection")
    except Exception as e:
        print("I am unable to connect to the database")
        print("Exception: {}".format(e))
    return conn


def call_rds_data_api(conn):
    rds_data = boto3.client('rds-data')
    print("sql execution started")
    sql = """
    SELECT JA.*
    FROM mpg_s2.ictJobAudit JA,
        mpg_s2.ictJobDim JD,
        mpg_s2.ictDataSrcSysDim DS
    WHERE JA.JobKey_FK = JD.JobKey_PK
        AND JD.SourceSystem_FK= DS.SourceSystem_PK
        AND DS.DataSourceName='EDW_E2'
        AND JD.jobName ='wf_MPGEDW_E1_To_E2_CaseClaimSelfServe'
        AND JA.JobStatusDescription='SUCCEEDED'
        AND JA.startTime > cast(getDate() AS Date);
          """
    cursor = conn.cursor()
    cursor.execute(sql)
    conn.commit()
    conn.close()
    print(str(response))


def opendbconn():
  Trusted_Connection = 'yes'
  cnxn = pyodbc.connect('Trusted_Connection=+Trusted_Connection+',DRIVER='{ODBC Driver 17 for SQL Server}',SERVER='DEVSDB015',DATABASE='MPG_EDW_DEV')
  print("cnxn:  ", cnxn)
  return cnxn




def lambda_handler(event, context):
    try:
        print("event: {}".format(event))
        cnn = make_conn()
        print(cnxn)
        cursor=cnxn.cursor()
        #sql_query="select * from "
        for row in cursor.tables():
            print(row.table_name)
        
        #call_rds_data_api(conn)
    except Exception as e:
        print("Failed to process Index files. Exception: {}".format(e))