import json
import boto3
import os
from urllib.parse import unquote_plus
from elasticsearch import Elasticsearch, RequestsHttpConnection
from pathlib import Path, PurePath
import re
from requests_aws4auth import AWS4Auth
from datetime import datetime, timedelta
from pytz import timezone
ET = timezone('US/Eastern') 

class ElasticsearchIndexCreator:
    def __init__(self, response, bucketName, objectName):
        self.response = response
        self.bucketName = bucketName
        self.objectName = PurePath(objectName).name
        self.s3location = "s3://{}/{}".format(bucketName, objectName)
    
    def _getFileId(self, ObjName):
        while "." in ObjName:
            ObjName = Path(ObjName).stem
        return ObjName

    def get_doc_results_from_aurora(self, file_id):
        rds_data = boto3.client('rds-data')
        cluster_arn = os.environ['AURORA_CLUSTER_ARN']
        secret_arn = os.environ['RDS_SECRET_ARN']
        doc_metadata_table = os.environ['DOC_METADATA_TABLE']

        sql = """
                SELECT 
                fileid,
                documentid,
                metarep.daily_index_metadata.casenumber,
                description,
                type,
                location,
                category,
                pagenumber,
                documentdate,
                claimlob,
                caseclaimstatus,
                claimtransactionamount,
                claimfinaldispositioncode,
                claimcounty,
                claimcity,
                claimstate,
                defendant,
                filemanager,
                patient,
                plantiffattorney,
                condition
                FROM metarep.daily_index_metadata
                LEFT JOIN metarep.ES_META_SUMMARY ON TRIM(metarep.daily_index_metadata.casenumber)=TRIM(metarep.ES_META_SUMMARY.casenumber) 
                where metarep.daily_index_metadata.fileid = cast(:file_id as bigint) limit 1;
            """
        print(int(file_id))
        print(sql)
        param1 = {'name':'file_id', 'value':{'stringValue': file_id}}
        print(param1)
        param_set = [param1]
    
        response = rds_data.execute_statement(
            continueAfterTimeout=True,
            resourceArn = cluster_arn, 
            secretArn = secret_arn, 
            database = doc_metadata_table, 
            sql = sql,
            parameters = param_set)
        print("Response : " + str(response))
        
        data = {}
        if  len(response['records']) > 0:
            dataObj = response['records'][0]
            data = {
                "Onbase_Docid": '' if 'isNull' in dataObj[1] else str(dataObj[1]['longValue']),
                "CaseNumber": '' if 'isNull' in dataObj[2] else dataObj[2]['stringValue'],
                "Description": '' if 'isNull' in dataObj[3] else dataObj[3]['stringValue'],
                "Document_Type": '' if 'isNull' in dataObj[4] else dataObj[4]['stringValue'],
                "Onbase_Location": '' if 'isNull' in dataObj[5] else dataObj[5]['stringValue'],
                "Category": '' if 'isNull' in dataObj[6] else dataObj[6]['stringValue'],
                "Onbase_Doc_Date": '' if 'isNull' in dataObj[8] else dataObj[8]['stringValue'],
                "ClaimLOB": '' if 'isNull' in dataObj[9] else dataObj[9]['stringValue'],
                "CaseClaimStatus": '' if 'isNull' in dataObj[10] else dataObj[10]['stringValue'],
                "ClaimTransactionAmount": '' if 'isNull' in dataObj[11] else float(dataObj[11]['stringValue']),
                "ClaimFinalDispositionCode": '' if 'isNull' in dataObj[12] else dataObj[12]['stringValue'],
                "ClaimCounty": '' if 'isNull' in dataObj[13] else dataObj[13]['stringValue'],
                "ClaimCity": '' if 'isNull' in dataObj[14] else dataObj[14]['stringValue'],
                "ClaimState": '' if 'isNull' in dataObj[15] else dataObj[15]['stringValue'],
                "Defendant_Name": '' if 'isNull' in dataObj[16] else dataObj[16]['stringValue'],
                "File_Manager": '' if 'isNull' in dataObj[17] else dataObj[17]['stringValue'],
                "Patient_Name": '' if 'isNull' in dataObj[18] else dataObj[18]['stringValue'],
                "PlantiffLawyer": '' if 'isNull' in dataObj[19] else dataObj[19]['stringValue'],
                "Condition": '' if 'isNull' in dataObj[20] else dataObj[20]['stringValue']
            }

        print("Claims out: " + str(data))
        
        return data
        
   # def _getClaimDetails(self, documentId):
   #     #key = "{}/{}.json".format(self.metadataS3Prefix, documentId)
   #     key = "{}/{}.json".format(self.metadataS3Prefix, "all")
   #     claimDic = json.loads(self.metadataBucket.Object(key=key).get()["Body"].read())[documentId]
   #     return claimDic
    
    def _getIndexId(self, ObjName):
        print(ObjName)
        match = re.search('\d+.msg-attachment-(.+?)-(.+?)\..*', ObjName)
        if match:
            attachment_number = match.group(1)
            attachment_name = match.group(2)
            indexId = str(self._getFileId(ObjName)) + attachment_name + str(attachment_number)
        else:
            indexId = self._getFileId(ObjName)
        return indexId

    def _addToESIndex(self, s3URI, objectName, documentId, text):
            lambdaSession = boto3.Session()
            region = lambdaSession.region_name
            host=os.environ['ELASTICSEARCH_ENDPOINT']
            credentials = lambdaSession.get_credentials()
            awsauth = AWS4Auth(credentials.access_key, credentials.secret_key, region, 'es', session_token=credentials.token)
            indexId = self._getIndexId(self.objectName)
            print(indexId)

            es = Elasticsearch(
            hosts = [{'host': host, 'port':443}],
            use_ssl = True,
            verify_certs = True,
            http_auth=awsauth,
            connection_class = RequestsHttpConnection
            )

            document = {
            "fileName": "{}".format(objectName),
            "s3URI": "{}".format(s3URI),
            "content": text,
            "documentCreatedOn": datetime.now(ET)
            }
            match = re.search('(\d+).msg-attachment-(.+?)-(.+?)\..*', objectName)

            if match:
                parent_doc_id = match.group(1)
                attachment_number = match.group(2)
                onBaseDoc = {
                    "Onbase_Docid": str(parent_doc_id) + "_" + str(attachment_number)
                }
                doc_data = self.get_doc_results_from_aurora(str(parent_doc_id))
                doc_data.update(onBaseDoc)
                document.update(doc_data)
                documentObj = {
                    'doc': document
                }
                if es.exists(index="textractsearch", id=indexId):
                    es.update(index="textractsearch", doc_type="_doc", id=indexId, body=documentObj)
                    print("updated successfully for indexId {} from parent Index {}".format(indexId, parent_doc_id))
                else:
                    es.index(index="textractsearch", doc_type="_doc", id=indexId, body=document)
                    print("New record added in Elasticsearch for indexId {}".format(indexId))
            else:
                doc_data = self.get_doc_results_from_aurora(indexId)
                document.update(doc_data)
                documentObj = {
                    'doc': document
                }
                if es.exists(index="textractsearch", id=indexId):
                    es.update(index="textractsearch", doc_type="_doc", id=indexId, body=documentObj)
                    print("Elasticsearch record updated successfully for indexId {}".format(indexId))
                else:
                    es.index(index="textractsearch", doc_type="_doc", id=indexId, body=document)
                    print("New record added in Elasticsearch for indexId {}".format(indexId))
          

            #claimDic = self._getClaimDetails(documentId)
            #document.update(claimDic)

    def _outputText(self, response):
        text=""
        for parentblocks in response:
            blocks = parentblocks['Blocks']
            for item in blocks:
                if item["BlockType"] == "LINE":
                    text += " "+item["Text"]+" "
        return text
    
    def _outputTextFromImage(self, response):
        text=""
        blocks = response['Blocks']
        for item in blocks:
            if item["BlockType"] == "LINE":
                text += " "+item["Text"]+" "
        return text

    def publish_image_content(self):
        fileId = self._getFileId(self.objectName)
        #Get the text blocks
        doc_text = self._outputTextFromImage(self.response)
        self._addToESIndex(self.s3location,self.objectName,fileId, doc_text)

    def publish(self):
        fileId = self._getFileId(self.objectName)
        #Get the text blocks
        doc_text = self._outputText(self.response)
        self._addToESIndex(self.s3location,self.objectName,fileId, doc_text)

    def publish_content(self):
        print("response for sync {}".format(self.response))
        fileId = self._getFileId(self.objectName)
        #Get the text blocks
        #doc_text = self._outputText(self.response)
        print(fileId)
        self._addToESIndex(self.s3location,self.objectName,fileId, self.response)

