
SELECT top 1 JA.* FROM mpg_s2.ictJobAudit JA, mpg_s2.ictJobDim JD,  mpg_s2.ictDataSrcSysDim DS WHERE JA.JobKey_FK = JD.JobKey_PK AND JD.SourceSystem_FK= DS.SourceSystem_PK AND DS.DataSourceName='EDW_E2' AND JD.jobName ='wf_MPGEDW_E1_To_E2_CaseClaimSelfServe' AND JA.JobStatusDescription='SUCCEEDED' AND JA.startTime > cast(getDate()-10 AS Date) order by JA.EndTime desc;


==========    medpro-dev-ds-edw-trigger-glue-jobs-lambda  =======
AURORA_LOG_TABLE	metarep.daily_glue_trigger_log
DB_NAME	claimsdb
EDW_DB_DATABASE	MPG_STG_DEV
EDW_DB_PORT	1433
EDW_DB_SECTET	arn:aws:secretsmanager:us-east-2:613640794830:secret:medpro-dev-ds-edw-on-prem-sql-server-4YNI9c
EDW_DB_SERVER	10.2.26.54
EDW_STEP_FUNC	arn:aws:states:us-east-2:613640794830:stateMachine:medpro-dev-ds-etl
RDS_Endpoint	medpro-dev-ds-claims-metadata-db.cluster-cpaevzeeipsp.us-east-2.rds.amazonaws.com
RDS_PORT	5432
RDS_SECRET_ARN	arn:aws:secretsmanager:us-east-2:613640794830:secret:medpro-dev-ds-edw-rds-aurora-StaJ2k

vpc-0b37fec526916ca52 (10.20.16.0/22) | vpc-us-east-2-datascience-lower-dev
Subnets
    subnet-0b4b3a8e88c9b5e66 (10.20.18.0/24) | us-east-2b, sbn-us-east-2-datascience-lower-private-dev
    subnet-07fa4565d5992fa95 (10.20.17.0/24) | us-east-2a, sbn-us-east-2-datascience-lower-private-dev
Security groups
    sg-0d21ec677d5354b8c (medpro-dev-ds-datalake-shared-lambda-sg) | medpro-dev-ds-datalake-shared-lambda-sg
    

==========  Test4 =================
AURORA_LOG_TABLE	metarep.daily_glue_trigger_log
DB_NAME	claimsdb
EDW_DB_DATABASE	MPG_STG_UAT
EDW_DB_PORT	1433
EDW_DB_SECTET	arn:aws:secretsmanager:us-east-2:613640794830:secret:medpro-uat-ds-edw-on-prem-sql-server-x5lCXt
EDW_DB_SERVER	10.2.26.54
EDW_STEP_FUNC	arn:aws:states:us-east-2:613640794830:stateMachine:HelloworldforTest
RDS_Endpoint	medpro-dev-ds-claims-metadata-db.cluster-cpaevzeeipsp.us-east-2.rds.amazonaws.com
RDS_PORT	5432
RDS_SECRET_ARN	arn:aws:secretsmanager:us-east-2:613640794830:secret:medpro-dev-ds-edw-rds-aurora-StaJ2k

vpc-0b37fec526916ca52 (10.20.16.0/22) | vpc-us-east-2-datascience-lower-dev
Subnets
    subnet-0b4b3a8e88c9b5e66 (10.20.18.0/24) | us-east-2b, sbn-us-east-2-datascience-lower-private-dev
    subnet-07fa4565d5992fa95 (10.20.17.0/24) | us-east-2a, sbn-us-east-2-datascience-lower-private-dev
Security groups
    sg-0926753fc700e3572 (medpro-dev-ds-glue-sg) | medpro-dev-ds-glue-sg
    
    
=====================================

EDW_DB_DATABASE	MPG_STG_DEV          EDW_DB_DATABASE_UAT	MPG_STG_UAT

EDW_DB_SECTET	arn:aws:secretsmanager:us-east-2:613640794830:secret:medpro-dev-ds-edw-on-prem-sql-server-4YNI9c
EDW_DB_SECTET_UAT	arn:aws:secretsmanager:us-east-2:613640794830:secret:medpro-uat-ds-edw-on-prem-sql-server-x5lCXt

EDW_STEP_FUNC	arn:aws:states:us-east-2:613640794830:stateMachine:medpro-dev-ds-etl
EDW_STEP_FUNC_TEST	arn:aws:states:us-east-2:613640794830:stateMachine:HelloworldforTest

edw_step_func = os.environ['EDW_STEP_FUNC_TEST']
db_secret = os.environ['EDW_DB_SECTET_UAT']
db_name   = os.environ['EDW_DB_DATABASE_UAT']
===================================