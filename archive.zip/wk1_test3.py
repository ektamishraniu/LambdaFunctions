
EDW_DB_SECTET        arn:aws:secretsmanager:us-east-2:613640794830:secret:medpro-uat-ds-edw-on-prem-sql-server-x5lCXt
EDW_DB_SERVER        10.2.26.54   
EDW_DB_PORT          1433
EDW_DB_DATABASE      MPG_STG_UAT
AURORA_LOG_TABLE     metarep.daily_glue_trigger_log

aurora_log_table = "metarep.daily_glue_trigger_log"
Sql_insert_query = ("INSERT INTO "+ aurora_log_table +" (jobauditkey_pk, starttime, endtime, lastupdateby, lastupdatedate) VALUES(%s, %s, %s, %s, %s)") 
record  = (jobauditkey_pk, starttime, endtime, lastupdateby, timestamp)


select_sql = ("select * from "+ aurora_log_table " where jobauditkey_pk = %s")




import os
import boto3
import json
import pyodbc
pyodbc.pooling = False
import pg8000
import time
import datetime

step = boto3.client('stepfunctions')
rds_secretsmanager = boto3.client("secretsmanager", region_name="us-east-2")
rds_secret_arn = os.environ['RDS_SECRET_ARN']
rds_db_name = os.environ['DB_NAME']
rds_db_host=os.environ['RDS_Endpoint']
rds_db_port=os.environ['RDS_PORT']
ts = time.time()
timestamp = datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d %H:%M:%S')

db_secret = "arn:aws:secretsmanager:us-east-2:252759991802:secret:medpro-prod-ds-edw-on-prem-sql-server-36XLDF"
db_secret = "arn:aws:secretsmanager:us-east-2:613640794830:secret:medpro-uat-ds-edw-on-prem-sql-server-x5lCXt"

db_server = "10.1.25.67"  #PRODSDB015.medpro.com
db_server = "10.2.26.54"  #UATSDB015.medpro.com

db_port = "1433"
db_server = db_server + "," + db_port

db_name = "MPG_STG_PROD"
db_name = "MPG_STG_UAT"

s3 = boto3.resource('s3')
secretsmanager = boto3.client("secretsmanager", region_name="us-east-2")
lambdaSession = boto3.Session()
region = lambdaSession.region_name

def make_conn():
    conn = None
    try:
        get_secret_value_response = secretsmanager.get_secret_value(SecretId=db_secret)
        secret = get_secret_value_response['SecretString']
        secret = json.loads(secret)
        db_user = secret.get('username')
        db_pass = secret.get('password')
        conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER='+db_server+';DATABASE='+db_name+';UID='+db_user+';PWD='+db_pass)
        return conn
    except Exception as e:
        print("I am unable to connect to the database: ", e)
        return conn


def make_conn_pg800():
    conn_pg8000 = None
    try:
        get_secret_value_response = secretsmanager.get_secret_value(SecretId=rds_secret_arn)
        secret = get_secret_value_response['SecretString']
        secret = json.loads(secret)
        rds_db_user = secret.get('username')
        rds_db_pass = secret.get('password')
        conn_pg8000 = pg8000.connect(database=rds_db_name, user=rds_db_user, password=rds_db_pass, host=rds_db_host, port=rds_db_port)
        print("Successfully established pg8000 connection")
        return conn_pg8000
    except Exception as e:
        print("I am unable to connect to pg8000: ", e)
    #return conn_pg8000
   
   
def call_rds_data_api_to_add(jobauditkey_pk, starttime, endtime, conn_pg8000):
    try:
        cursor = conn_pg8000.cursor()
        lastupdateby = 'Batch_Job'
        Sql_insert_query = ("INSERT INTO metarep.daily_glue_trigger_log (jobauditkey_pk, starttime, endtime, lastupdateby, lastupdatedate) VALUES(%s, %s, %s, %s, %s)") 
        record  = (jobauditkey_pk, starttime, endtime, lastupdateby, timestamp)
        cursor.execute(Sql_insert_query , record)
        conn_pg8000.commit()
    except Exception as e:
        print('Insert Failed: ', e)
    finally:
        if conn_pg8000:
            cursor.close()
            conn_pg8000.close()
            print("conn_pg8000 connection is closed")

def runSelectQuery(conn):
    cursor = conn.cursor()
    sql = """
    SELECT top 1 JA.* FROM mpg_s2.ictJobAudit JA, mpg_s2.ictJobDim JD,  mpg_s2.ictDataSrcSysDim DS WHERE JA.JobKey_FK = JD.JobKey_PK AND JD.SourceSystem_FK= DS.SourceSystem_PK AND DS.DataSourceName='EDW_E2' AND JD.jobName ='wf_MPGEDW_E1_To_E2_CaseClaimSelfServe' AND JA.JobStatusDescription='SUCCEEDED' AND JA.startTime > cast(getDate()-10 AS Date) order by JA.EndTime desc;
    """
    cursor.execute(sql)
    tablist = list(cursor.fetchall())    
    cursor.close()
    del cursor
    conn.close()
    return tablist

def call_rds_data_api_select(conn_pg8000, received_jobauditkey_pk):
    try:
        cursor = conn_pg8000.cursor()
        select_sql = ("select * from metarep.daily_glue_trigger_log where jobauditkey_pk = %s")
        cursor.execute(select_sql, (received_jobauditkey_pk,))
        return cursor.rowcount
    except Exception as e:
        print('Unable to select current day Records: ', e)


def lambda_handler(event, context):
    try:
        conn_pg8000 = make_conn_pg800()
        if conn_pg8000 is None:
            print("conn_pg8000 is None, return called: ", conn_pg8000)
            return
        
        conn = make_conn()
        if conn is not None:
            result = runSelectQuery(conn)
            print(result)
            if len(result):
                currentday_record_check = call_rds_data_api_select(conn_pg8000, str(result[0][0]))
                if currentday_record_check == 0:
                    input = {}
                    response = step.start_execution(stateMachineArn='arn:aws:states:us-east-2:613640794830:stateMachine:HelloworldforTest', input=json.dumps(input))
                    print("Done with step function medpro-dev-ds-etl invocation: ", response)
                    call_rds_data_api_to_add(result[0][0], result[0][5], result[0][6], conn_pg8000)
                else:
                    print("Already processed for:  ", result[0][0], result[0][5], result[0][6])
                    
            else:
                print("hello")
                
        else:
            print("conn is None, return called: ", conn)
        #print(conn)
        #result = runSelectQuery(conn)
        #if len(result):
        #    print(result)
        #    if call_rds_data_api_select(conn_pg8000, str(result[0][0])) == 0:
        #        print("Start step function and insert entry in aurora: ", result[0][0], result[0][5], result[0][6])
        #        input = {}
        #        response = step.start_execution(stateMachineArn='arn:aws:states:us-east-2:613640794830:stateMachine:medpro-dev-ds-etl', input=json.dumps(input))
        #        print("Done with step function medpro-dev-ds-etl invocation: ", response)
        #        call_rds_data_api_to_add(result[0][0], result[0][5], result[0][6], conn_pg8000)
        #        return
        #    else:
        #        input = {}
        #        response = step.start_execution(stateMachineArn='arn:aws:states:us-east-2:613640794830:stateMachine:HelloworldforTest', input=json.dumps(input))
        #        print("Done with step function HelloworldforTest invocation: ", response)
        #        print("Already processed for:  ", result[0][0], result[0][5], result[0][6])
        #else:
        #    print("Data Yet not Uploaded:  ", result)

    except Exception as e:
        print("Failed to process Lambda: {}".format(e))


# JobAuditKey_PK	JobKey_FK	SourceSystem_FK	SourceKey_FK	RunTime	StartTime	EndTime	NumberOfSrcRecordsProc	NumberOfTgtRecordsProc	CheckSumSrc	CheckSumTgt	NumberOfErrors	BatchId	JobStatusCode	JobStatusDescription
# resultt[0][0]   20690                                    --- JobAuditKey_PK
# resultt[0][1]    2241
# resultt[0][2]      22
# resultt[0][3]     320
# resultt[0][4]   12.967
# resultt[0][5]   datetime.datetime(2021, 4, 20, 11, 5, 8)  --- StartTime_edw 
# resultt[0][6]   datetime.datetime(2021, 4, 20, 11, 18, 6)  -- EndTime_edw
#           YOU WILL BE INSETING THIS                       --- EntryTime

# resultt         [(20690, 2241, 22, 320, 12.967, datetime.datetime(2021, 4, 20, 11, 5, 8), datetime.datetime(2021, 4, 20, 11, 18, 6), None, None, None, None, None, '25756', '1', 'SUCCEEDED')]
 
# if len(resultt):
# Check at aurora table (daily_glue_trigger_log) if resultt[-1][0] OR JobAuditKey_PK nubmer is already there

# IF YES  -- Donot do anything

# IF NO  -- 
# Trigger the Glue step function
# And Insert Line to Aurora Table (daily_glue_trigger_log)  with EntryTime


# daily_glue_trigger_log  -->  JobAuditKey_PK               StartTime	                              EndTime                                     TimeOfEntry 
#                               20690,                 datetime.datetime(2021, 4, 20, 11, 5, 8),   datetime.datetime(2021, 4, 20, 11, 18, 6)        time.now()

#drop table metarep.daily_glue_trigger_log;
#create table metarep.daily_glue_trigger_log(jobauditkey_pk bigint PRIMARY KEY, starttime timestamp without time zone, endtime timestamp without time zone, lastupdateby text, lastupdatedate timestamp without time zone)






















####################################################################
import os
import boto3
import json
import pyodbc
pyodbc.pooling = False

db_secret = "arn:aws:secretsmanager:us-east-2:252759991802:secret:medpro-prod-ds-edw-on-prem-sql-server-36XLDF"
db_secret = "arn:aws:secretsmanager:us-east-2:613640794830:secret:medpro-uat-ds-edw-on-prem-sql-server-x5lCXt"

db_server = "10.1.25.67"  #PRODSDB015.medpro.com
db_server = "10.2.26.54"  #UATSDB015.medpro.com

db_port = "1433"
db_server = db_server + "," + db_port

db_name = "MPG_STG_PROD"
db_name = "MPG_STG_UAT"

s3 = boto3.resource('s3')
secretsmanager = boto3.client("secretsmanager", region_name="us-east-2")
lambdaSession = boto3.Session()
region = lambdaSession.region_name

def make_conn():
    conn = None
    try:
        get_secret_value_response = secretsmanager.get_secret_value(
            SecretId=db_secret
        )
        secret = get_secret_value_response['SecretString']
        secret = json.loads(secret)
        db_user = secret.get('username')
        db_pass = secret.get('password')

        print("DB info:  ", db_server, db_name, db_user)
        print("drivers:  ", pyodbc.drivers())
        conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER='+db_server+';DATABASE='+db_name+';UID='+db_user+';PWD='+db_pass)

        print("Successfully established connection: ", conn)
    except Exception as e:
        print("I am unable to connect to the database: ", e)
        #print("Exception: {}".format(e))
    return conn


def runSelectQuery(conn):
    cursor = conn.cursor()
    sql = """
    SELECT top 1 JA.* FROM mpg_s2.ictJobAudit JA, mpg_s2.ictJobDim JD,  mpg_s2.ictDataSrcSysDim DS WHERE JA.JobKey_FK = JD.JobKey_PK AND JD.SourceSystem_FK= DS.SourceSystem_PK AND DS.DataSourceName='EDW_E2' AND JD.jobName ='wf_MPGEDW_E1_To_E2_CaseClaimSelfServe' AND JA.JobStatusDescription='SUCCEEDED' AND JA.startTime > cast(getDate() AS Date) order by JA.EndTime desc;
    """
    cursor.execute(sql)
    tablist = list(cursor.fetchall())    
    cursor.close()
    del cursor
    conn.close()
    return tablist


def lambda_handler(event, context):
    try:
        print("event: {}".format(event))
        conn = make_conn()
        result = runSelectQuery(conn) 

        if len(result):
            print(result)
            print("Data Got Uploaded:  ", result[-1][0],  result )
        else:
            print("Data Yet not Uploaded:  ", result,  result)
        return

    except Exception as e:
        print("Failed to process Index files. Exception: {}".format(e))
        return

    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }

# JobAuditKey_PK	JobKey_FK	SourceSystem_FK	SourceKey_FK	RunTime	StartTime	EndTime	NumberOfSrcRecordsProc	NumberOfTgtRecordsProc	CheckSumSrc	CheckSumTgt	NumberOfErrors	BatchId	JobStatusCode	JobStatusDescription

# resultt[0][0]   20690                                    --- JobAuditKey_PK
# resultt[0][1]    2241
# resultt[0][2]      22
# resultt[0][3]     320
# resultt[0][4]   12.967
# resultt[0][5]   datetime.datetime(2021, 4, 20, 11, 5, 8)  --- StartTime_edw 
# resultt[0][6]   datetime.datetime(2021, 4, 20, 11, 18, 6)  -- EndTime_edw
#           YOU WILL BE INSETING THIS                       --- EntryTime

# resultt         [(20690, 2241, 22, 320, 12.967, datetime.datetime(2021, 4, 20, 11, 5, 8), datetime.datetime(2021, 4, 20, 11, 18, 6), None, None, None, None, None, '25756', '1', 'SUCCEEDED')]
 
# if len(resultt):
# Check at aurora table (daily_glue_trigger_log) if resultt[-1][0] OR JobAuditKey_PK nubmer is already there

# IF YES  -- Donot do anything

# IF NO  -- 
# Trigger the Glue step function
# And Insert Line to Aurora Table (daily_glue_trigger_log)  with EntryTime

# daily_glue_trigger_log  -->  JobAuditKey_PK               StartTime	                              EndTime                                     TimeOfEntry 
#                               20690,                 datetime.datetime(2021, 4, 20, 11, 5, 8),   datetime.datetime(2021, 4, 20, 11, 18, 6)        time.now()




drop table metarep.daily_glue_trigger_log;
create table metarep.daily_glue_trigger_log(jobauditkey_pk bigint PRIMARY KEY, starttime timestamp without time zone, endtime timestamp without time zone, lastupdateby text, lastupdatedate timestamp without time zone)






















##################################################################

import os
import boto3
import json
import pyodbc
pyodbc.pooling = False


db_secret = "arn:aws:secretsmanager:us-east-2:252759991802:secret:medpro-prod-ds-edw-on-prem-sql-server-36XLDF"
db_secret = "arn:aws:secretsmanager:us-east-2:613640794830:secret:medpro-uat-ds-edw-on-prem-sql-server-x5lCXt"

db_server = "10.1.25.67"  #PRODSDB015.medpro.com
db_server = "10.2.26.54"  #UATSDB015.medpro.com

db_port = "1433"
db_server = db_server + "," + db_port

db_name = "MPG_STG_PROD"
db_name = "MPG_STG_UAT"

s3 = boto3.resource('s3')
secretsmanager = boto3.client("secretsmanager", region_name="us-east-2")
lambdaSession = boto3.Session()
region = lambdaSession.region_name

def make_conn():
    conn = None
    try:
        get_secret_value_response = secretsmanager.get_secret_value(
            SecretId=db_secret
        )
        secret = get_secret_value_response['SecretString']
        secret = json.loads(secret)
        db_user = secret.get('username')
        db_pass = secret.get('password')

        print("DB info:  ", db_server, db_name, db_user)
        print("drivers:  ", pyodbc.drivers())
        conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER='+db_server+';DATABASE='+db_name+';UID='+db_user+';PWD='+db_pass)

        print("Successfully established connection: ", conn)
    except Exception as e:
        print("I am unable to connect to the database: ", e)
        print("Exception: {}".format(e))
    return conn


def runSelectQuery(conn):
    cursor = conn.cursor()
    sql = """
    SELECT top 1 JA.* FROM mpg_s2.ictJobAudit JA, mpg_s2.ictJobDim JD,  mpg_s2.ictDataSrcSysDim DS WHERE JA.JobKey_FK = JD.JobKey_PK AND JD.SourceSystem_FK= DS.SourceSystem_PK AND DS.DataSourceName='EDW_E2' AND JD.jobName ='wf_MPGEDW_E1_To_E2_CaseClaimSelfServe' AND JA.JobStatusDescription='SUCCEEDED' AND JA.startTime > cast(getDate()-10 AS Date) order by JA.EndTime desc;
    """
    cursor.execute(sql)
    tablist = list(cursor.fetchall())    
    cursor.close()
    del cursor
    conn.close()
    return tablist
    


def lambda_handler(event, context):
    try:
        print("event: {}".format(event))
        conn = make_conn()
        resultt = runSelectQuerySure(conn) 

        if len(resultt):
            print("Data Got Uploaded:  ", resultt[-1][0],  resultt )
        else:
            print("Data Yet not Uploaded:  ", resultt,  resultt)

    except Exception as e:
        print("Failed to process Index files. Exception: {}".format(e))

    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }

JobAuditKey_PK	JobKey_FK	SourceSystem_FK	SourceKey_FK	RunTime	StartTime	EndTime	NumberOfSrcRecordsProc	NumberOfTgtRecordsProc	CheckSumSrc	CheckSumTgt	NumberOfErrors	BatchId	JobStatusCode	JobStatusDescription
[(20690, 2241, 22, 320, 12.967, datetime.datetime(2021, 4, 20, 11, 5, 8), datetime.datetime(2021, 4, 20, 11, 18, 6), None, None, None, None, None, '25756', '1', 'SUCCEEDED')]




vpc-0b37fec526916ca52 (10.20.16.0/22) | vpc-us-east-2-datascience-lower-dev
Subnets

    subnet-0b4b3a8e88c9b5e66 (10.20.18.0/24) | us-east-2b, sbn-us-east-2-datascience-lower-private-dev
    subnet-0e916b045c8fd56a6 (10.20.19.0/25) | us-east-2a, sbn-us-east-2-datascience-lower-data-dev
    subnet-048e043ed6c5f867c (10.20.19.128/25) | us-east-2b, sbn-us-east-2-datascience-lower-data-dev
    subnet-07fa4565d5992fa95 (10.20.17.0/24) | us-east-2a, sbn-us-east-2-datascience-lower-private-dev

Security groups

    sg-0d21ec677d5354b8c (medpro-dev-ds-datalake-shared-lambda-sg) | medpro-dev-ds-datalake-shared-lambda-sg
    sg-0926753fc700e3572 (medpro-dev-ds-glue-sg) | medpro-dev-ds-glue-sg

    Inbound rules
    Outbound rules

Security group ID	Protocol	Ports	Source
sg-0926753fc700e3572	All	All	sg-0926753fc700e3572





#####################################################




import os
import boto3
import json
import pyodbc
pyodbc.pooling = False

#db_secret=os.environ['RDS_SECRET_ARN']
#db_name=os.environ['RDS_DB_NAME']
#db_host=os.environ['RDS_Endpoint']
#db_port=os.environ['RDS_PORT']

db_secret = "arn:aws:secretsmanager:us-east-2:252759991802:secret:medpro-prod-ds-edw-on-prem-sql-server-36XLDF"
db_secret = "arn:aws:secretsmanager:us-east-2:613640794830:secret:medpro-uat-ds-edw-on-prem-sql-server-x5lCXt"

db_server = "10.1.25.67"  #PRODSDB015.medpro.com
db_server = "10.2.26.54"  #UATSDB015.medpro.com
#db_server = "10.2.26.44"  #DEVSDB015.medpro.com
db_port = "1433"
db_server = db_server + "," + db_port

db_name = "MPG_STG_PROD"
db_name = "MPG_STG_UAT"
#db_name = "MPG_STG_DEV"
#db_name = 'MPG_EDW_UAT'

s3 = boto3.resource('s3')
secretsmanager = boto3.client("secretsmanager", region_name="us-east-2")
lambdaSession = boto3.Session()
region = lambdaSession.region_name

def make_conn():
    conn = None
    try:
        get_secret_value_response = secretsmanager.get_secret_value(
            SecretId=db_secret
        )
        secret = get_secret_value_response['SecretString']
        secret = json.loads(secret)
        db_user = secret.get('username')
        db_pass = secret.get('password')

        print("DB info:  ", db_server, db_name, db_user)
        print("drivers:  ", pyodbc.drivers())
        conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER='+db_server+';DATABASE='+db_name+';UID='+db_user+';PWD='+db_pass)

        print("Successfully established connection: ", conn)
    except Exception as e:
        print("I am unable to connect to the database: ", e)
        print("Exception: {}".format(e))
    return conn

def printAllTableNames(conn):
    cursor=conn.cursor()
    for row in cursor.tables():
        if "ict" in row.table_name:
            print("table: ", row.table_name)
    cursor.close()
    del cursor
    conn.close()
    return

def runSelectQuery(conn):
    cursor = conn.cursor()
    sql = """
    SELECT top 1 JA.* FROM mpg_s2.ictJobAudit JA, mpg_s2.ictJobDim JD,  mpg_s2.ictDataSrcSysDim DS WHERE JA.JobKey_FK = JD.JobKey_PK AND JD.SourceSystem_FK= DS.SourceSystem_PK AND DS.DataSourceName='EDW_E2' AND JD.jobName ='wf_MPGEDW_E1_To_E2_CaseClaimSelfServe' AND JA.JobStatusDescription='SUCCEEDED' AND JA.startTime > cast(getDate() AS Date) order by JA.EndTime desc;
    """
    cursor.execute(sql)
    tablist = list(cursor.fetchall())
    cursor.close()
    del cursor
    conn.close()
    return tablist
    

def runSelectQuerySure(conn):
    cursor = conn.cursor()
    sql = """
    SELECT top 1 JA.* FROM mpg_s2.ictJobAudit JA, mpg_s2.ictJobDim JD,  mpg_s2.ictDataSrcSysDim DS WHERE JA.JobKey_FK = JD.JobKey_PK AND JD.SourceSystem_FK= DS.SourceSystem_PK AND DS.DataSourceName='EDW_E2' AND JD.jobName ='wf_MPGEDW_E1_To_E2_CaseClaimSelfServe' AND JA.JobStatusDescription='SUCCEEDED' AND JA.startTime > cast(getDate()-10 AS Date) order by JA.EndTime desc;
    """
    cursor.execute(sql)
    #columns = [column[0] for column in cursor.description]
    #results = [columns] + [row for row in cursor.fetchall()]
    #print("results\n",  results)    
    tablist = list(cursor.fetchall())    
    cursor.close()
    del cursor
    conn.close()
    return tablist
    
    

def runSelectQueryNull(conn):
    cursor = conn.cursor()
    sql = """
    SELECT top 1 JA.* FROM mpg_s2.ictJobAudit JA, mpg_s2.ictJobDim JD,  mpg_s2.ictDataSrcSysDim DS WHERE JA.JobKey_FK = JD.JobKey_PK AND JD.SourceSystem_FK= DS.SourceSystem_PK AND DS.DataSourceName='EDW_E2' AND JD.jobName ='wf_MPGEDW_E1_To_E2_CaseClaimSelfServe' AND JA.JobStatusDescription='SUCCEEDED' AND JA.startTime > cast(getDate()+1 AS Date) order by JA.EndTime desc;
    """
    cursor.execute(sql)
    tablist = list(cursor.fetchall())
    columns = list(cursor.description)
    print("Columns:  ", columns, tablist)
    cursor.close()
    conn.close()
    del cursor
    return tablist



def lambda_handler(event, context):
    try:
        print("event: {}".format(event))
        conn = make_conn()
        #printAllTableNames(conn)
        #resultt = runSelectQuery(conn)
        #resultt = runSelectQueryNull(conn)
        resultt = runSelectQuerySure(conn) 

        if len(resultt):
            print("Data Got Uploaded:  ", resultt[-1][0],  resultt )
        else:
            print("Data Yet not Uploaded:  ", resultt,  resultt)

    except Exception as e:
        print("Failed to process Index files. Exception: {}".format(e))











####################################################
import os
import boto3
import json
import pyodbc
pyodbc.pooling = False

#db_secret=os.environ['RDS_SECRET_ARN']
#db_name=os.environ['RDS_DB_NAME']
#db_host=os.environ['RDS_Endpoint']
#db_port=os.environ['RDS_PORT']

db_secret = "arn:aws:secretsmanager:us-east-2:252759991802:secret:medpro-prod-ds-edw-on-prem-sql-server-36XLDF"
db_secret = "arn:aws:secretsmanager:us-east-2:613640794830:secret:medpro-uat-ds-edw-on-prem-sql-server-x5lCXt"

db_server = "10.1.25.67"  #PRODSDB015.medpro.com
db_server = "10.2.26.54"  #UATSDB015.medpro.com
#db_server = "10.2.26.44"  #DEVSDB015.medpro.com
db_port = "1433"
db_server = db_server + "," + db_port

db_name = "MPG_STG_PROD"
db_name = "MPG_STG_UAT"
#db_name = "MPG_STG_DEV"
#db_name = 'MPG_EDW_UAT'

s3 = boto3.resource('s3')
secretsmanager = boto3.client("secretsmanager", region_name="us-east-2")
lambdaSession = boto3.Session()
region = lambdaSession.region_name

def make_conn():
    conn = None
    try:
        get_secret_value_response = secretsmanager.get_secret_value(
            SecretId=db_secret
        )
        secret = get_secret_value_response['SecretString']
        secret = json.loads(secret)
        db_user = secret.get('username')
        db_pass = secret.get('password')

        print("DB info:  ", db_server, db_name, db_user)
        print("drivers:  ", pyodbc.drivers())
        conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER='+db_server+';DATABASE='+db_name+';UID='+db_user+';PWD='+db_pass)

        print("Successfully established connection: ", conn)
    except Exception as e:
        print("I am unable to connect to the database: ", e)
        print("Exception: {}".format(e))
    return conn

def printAllTableNames(conn):
    cursor=conn.cursor()
    for row in cursor.tables():
        if "ict" in row.table_name:
            print("table: ", row.table_name)
    cursor.close()
    del cursor
    conn.close()
    return

def runSelectQuery(conn):
    cursor = conn.cursor()
    sql = """
    SELECT JA.* FROM mpg_s2.ictJobAudit JA, mpg_s2.ictJobDim JD,  mpg_s2.ictDataSrcSysDim DS WHERE JA.JobKey_FK = JD.JobKey_PK AND JD.SourceSystem_FK= DS.SourceSystem_PK AND DS.DataSourceName='EDW_E2' AND JD.jobName ='wf_MPGEDW_E1_To_E2_CaseClaimSelfServe' AND JA.JobStatusDescription='SUCCEEDED' AND JA.startTime > cast(getDate() AS Date);
    """
    cursor.execute(sql)
    tablist = list(cursor.fetchall())
    columns = list(cursor.description)
    print("Columns:  ", columns, tablist)
    cursor.close()
    del cursor
    conn.close()
    return tablist
    

def runSelectQuerySure(conn):
    cursor = conn.cursor()
    sql = """
    SELECT JA.* FROM mpg_s2.ictJobAudit JA, mpg_s2.ictJobDim JD,  mpg_s2.ictDataSrcSysDim DS WHERE JA.JobKey_FK = JD.JobKey_PK AND JD.SourceSystem_FK= DS.SourceSystem_PK AND DS.DataSourceName='EDW_E2' AND JD.jobName ='wf_MPGEDW_E1_To_E2_CaseClaimSelfServe' AND JA.JobStatusDescription='SUCCEEDED' AND JA.startTime > cast(getDate()-10 AS Date);
    """
    cursor.execute(sql)
    tablist = list(cursor.fetchall())
    columns = list(cursor.description)
    print("Columns:  ", columns, tablist)
    cursor.close()
    del cursor
    conn.close()
    return tablist
    
    

def runSelectQueryNull(conn):
    cursor = conn.cursor()
    sql = """
    SELECT JA.* FROM mpg_s2.ictJobAudit JA, mpg_s2.ictJobDim JD,  mpg_s2.ictDataSrcSysDim DS WHERE JA.JobKey_FK = JD.JobKey_PK AND JD.SourceSystem_FK= DS.SourceSystem_PK AND DS.DataSourceName='EDW_E2' AND JD.jobName ='wf_MPGEDW_E1_To_E2_CaseClaimSelfServe' AND JA.JobStatusDescription='SUCCEEDED' AND JA.startTime > cast(getDate()+1 AS Date);
    """
    cursor.execute(sql)
    tablist = list(cursor.fetchall())
    columns = list(cursor.description)
    print("Columns:  ", columns, tablist)
    cursor.close()
    conn.close()
    del cursor
    return tablist



def lambda_handler(event, context):
    try:
        print("event: {}".format(event))
        conn = make_conn()
        #printAllTableNames(conn)
        #resultt = runSelectQuery(conn)
        #resultt = runSelectQueryNull(conn)
        resultt = runSelectQuerySure(conn)        
        print("resultt: ", resultt, len(resultt))
        
        if len(resultt):
            print("Data Got Uploaded:  ", resultt, len(resultt))
        else:
            print("Data Yet not Uploaded:  ", resultt, len(resultt))
        

            
    except Exception as e:
        print("Failed to process Index files. Exception: {}".format(e))












=== Prod ===
db_secret = "arn:aws:secretsmanager:us-east-2:252759991802:secret:medpro-prod-ds-edw-on-prem-sql-server-36XLDF"
db_server = "10.1.25.67"  #PRODSDB015.medpro.com
db_name = "MPG_STG_PROD"

=== UAT ===
db_secret = "arn:aws:secretsmanager:us-east-2:613640794830:secret:medpro-uat-ds-edw-on-prem-sql-server-x5lCXt"
db_server = "10.2.26.54"  #UATSDB015.medpro.com
db_name = "MPG_STG_UAT"


import os
import boto3
import json
import pyodbc
pyodbc.pooling = False

#db_secret=os.environ['RDS_SECRET_ARN']
#db_name=os.environ['RDS_DB_NAME']
#db_host=os.environ['RDS_Endpoint']
#db_port=os.environ['RDS_PORT']

db_secret = "arn:aws:secretsmanager:us-east-2:252759991802:secret:medpro-prod-ds-edw-on-prem-sql-server-36XLDF"
db_secret = "arn:aws:secretsmanager:us-east-2:613640794830:secret:medpro-uat-ds-edw-on-prem-sql-server-x5lCXt"

db_server = "10.1.25.67"  #PRODSDB015.medpro.com
db_server = "10.2.26.54"  #UATSDB015.medpro.com
#db_server = "10.2.26.44"  #DEVSDB015.medpro.com
db_port = "1433"
db_server = db_server + "," + db_port

db_name = "MPG_STG_PROD"
db_name = "MPG_STG_UAT"
#db_name = "MPG_STG_DEV"
#db_name = 'MPG_EDW_UAT'

s3 = boto3.resource('s3')
secretsmanager = boto3.client("secretsmanager", region_name="us-east-2")
lambdaSession = boto3.Session()
region = lambdaSession.region_name

def make_conn():
    conn = None
    try:
        get_secret_value_response = secretsmanager.get_secret_value(
            SecretId=db_secret
        )
        secret = get_secret_value_response['SecretString']
        secret = json.loads(secret)
        db_user = secret.get('username')
        db_pass = secret.get('password')

        print("DB info:  ", db_server, db_name, db_user)
        print("drivers:  ", pyodbc.drivers())
        conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER='+db_server+';DATABASE='+db_name+';UID='+db_user+';PWD='+db_pass)

        print("Successfully established connection: ", conn)
    except Exception as e:
        print("I am unable to connect to the database: ", e)
        print("Exception: {}".format(e))
    return conn

def printAllTableNames(conn):
    cursor=conn.cursor()
    for row in cursor.tables():
        if "ict" in row.table_name:
            print("table: ", row.table_name)
    cursor.close()
    del cursor
    conn.close()
    return

def runSelectQuery(conn):
    cursor = conn.cursor()
    sql = """
    SELECT JA.* FROM mpg_s2.ictJobAudit JA, mpg_s2.ictJobDim JD,  mpg_s2.ictDataSrcSysDim DS WHERE JA.JobKey_FK = JD.JobKey_PK AND JD.SourceSystem_FK= DS.SourceSystem_PK AND DS.DataSourceName='EDW_E2' AND JD.jobName ='wf_MPGEDW_E1_To_E2_CaseClaimSelfServe' AND JA.JobStatusDescription='SUCCEEDED' AND JA.startTime > cast(getDate() AS Date);
    """
    cursor.execute(sql)
    tablist = list(cursor.fetchall())
    columns = list(cursor.description)
    print("Columns:  ", columns, tablist)
    cursor.close()
    del cursor
    conn.close()
    return tablist
    

def runSelectQueryNull(conn):
    cursor = conn.cursor()
    sql = """
    SELECT JA.* FROM mpg_s2.ictJobAudit JA, mpg_s2.ictJobDim JD,  mpg_s2.ictDataSrcSysDim DS WHERE JA.JobKey_FK = JD.JobKey_PK AND JD.SourceSystem_FK= DS.SourceSystem_PK AND DS.DataSourceName='EDW_E2' AND JD.jobName ='wf_MPGEDW_E1_To_E2_CaseClaimSelfServe' AND JA.JobStatusDescription='SUCCEEDED' AND JA.startTime > cast(getDate()+1 AS Date);
    """
    cursor.execute(sql)
    tablist = list(cursor.fetchall())
    columns = list(cursor.description)
    print("Columns:  ", columns, tablist)
    cursor.close()
    conn.close()
    del cursor
    return tablist



def lambda_handler(event, context):
    try:
        print("event: {}".format(event))
        conn = make_conn()
        #printAllTableNames(conn)
        resultt = runSelectQuery(conn)
        resultt = runSelectQueryNull(conn)        
        print("resultt: ", resultt, len(resultt))
        
        if len(resultt):
            print("Data Got Uploaded:  ", resultt, len(resultt))
        else:
            print("Data Yet not Uploaded:  ", resultt, len(resultt))
        

            
    except Exception as e:
        print("Failed to process Index files. Exception: {}".format(e))

































##############################################################
import os, re
import io
import boto3
import botocore
import csv
from pathlib import Path, PurePath
import json, time
from datetime import datetime
import pyodbc

#db_secret=os.environ['RDS_SECRET_ARN']
#db_name=os.environ['RDS_DB_NAME']
#db_host=os.environ['RDS_Endpoint']
#db_port=os.environ['RDS_PORT']

db_secret = "arn:aws:secretsmanager:us-east-2:252759991802:secret:medpro-prod-ds-edw-on-prem-sql-server-36XLDF"
db_secret = "arn:aws:secretsmanager:us-east-2:613640794830:secret:medpro-uat-ds-edw-on-prem-sql-server-x5lCXt"

db_server = "10.1.25.67"  #PRODSDB015.medpro.com
db_server = "10.2.26.54"  #UATSDB015.medpro.com
#db_server = "10.2.26.44"  #DEVSDB015.medpro.com
db_port = "1433"
db_server = db_server + "," + db_port

db_name = "MPG_STG_PROD"
db_name = "MPG_STG_UAT"
#db_name = "MPG_STG_DEV"
#db_name = 'MPG_EDW_UAT'

s3 = boto3.resource('s3')
secretsmanager = boto3.client("secretsmanager", region_name="us-east-2")
lambdaSession = boto3.Session()
region = lambdaSession.region_name

def make_conn():
    conn = None
    try:
        get_secret_value_response = secretsmanager.get_secret_value(
            SecretId=db_secret
        )
        secret = get_secret_value_response['SecretString']
        secret = json.loads(secret)
        db_user = secret.get('username')
        db_pass = secret.get('password')

        print("DB info:  ", db_server, db_name, db_user)
        conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER='+db_server+';DATABASE='+db_name+';UID='+db_user+';PWD='+db_pass)

        print("Successfully established connection: ", conn)
    except Exception as e:
        print("I am unable to connect to the database: ", e)
        print("Exception: {}".format(e))
    return conn

def printAllTableNames(conn):
    cursor=conn.cursor()
    for row in cursor.tables():
        print("table: ", row.table_name)
    conn.close()


def call_rds_data_api(conn):
    rds_data = boto3.client('rds-data')
    print("sql execution started")
    sql = """
    SELECT JA.*
    FROM mpg_s2.ictJobAudit JA,
        mpg_s2.ictJobDim JD,
        mpg_s2.ictDataSrcSysDim DS
    WHERE JA.JobKey_FK = JD.JobKey_PK
        AND JD.SourceSystem_FK= DS.SourceSystem_PK
        AND DS.DataSourceName='EDW_E2'
        AND JD.jobName ='wf_MPGEDW_E1_To_E2_CaseClaimSelfServe'
        AND JA.JobStatusDescription='SUCCEEDED';
        --AND JA.startTime > cast(getDate() AS Date);
          """
    cursor = conn.cursor()
    cursor.execute(sql)
    response = cursor.fetchall()
    conn.commit()
    conn.close()
    print(str(response))

def lambda_handler(event, context):
    try:
        print("event: {}".format(event))
        conn = make_conn()
        #printAllTableNames(conn)
        call_rds_data_api(conn)
        
    except Exception as e:
        print("Failed to process Index files. Exception: {}".format(e))


    select * from  mpg_s2.ictJobAudit;
    
    SELECT JA.* FROM mpg_s2.ictJobAudit JA, mpg_s2.ictJobDim JD,  mpg_s2.ictDataSrcSysDim DS WHERE JA.JobKey_FK = JD.JobKey_PK AND JD.SourceSystem_FK= DS.SourceSystem_PK AND DS.DataSourceName='EDW_E2' AND JD.jobName ='wf_MPGEDW_E1_To_E2_CaseClaimSelfServe' AND JA.JobStatusDescription='SUCCEEDED' AND JA.startTime > cast(getDate() AS Date);



    columns = [column[0] for column in cursor.description]
    results = [columns] + [row for row in cursor.fetchall()]
    return results







#########################   V0  ########################################
import os, re
import io
import boto3
import botocore
import csv
from pathlib import Path, PurePath
import json, time
from datetime import datetime
import pyodbc

#db_secret=os.environ['RDS_SECRET_ARN']
#db_name=os.environ['RDS_DB_NAME']
#db_host=os.environ['RDS_Endpoint']
#db_port=os.environ['RDS_PORT']

db_secret = "arn:aws:secretsmanager:us-east-2:252759991802:secret:medpro-prod-ds-edw-on-prem-sql-server-36XLDF"
db_secret = "arn:aws:secretsmanager:us-east-2:613640794830:secret:medpro-uat-ds-edw-on-prem-sql-server-x5lCXt"

db_server = "10.1.25.67"  #PRODSDB015.medpro.com
db_server = "10.2.26.54"  #UATSDB015.medpro.com
#db_server = "10.2.26.44"  #DEVSDB015.medpro.com
db_port = "1433"
db_server = db_server + "," + db_port

db_name = "MPG_STG_PROD"
db_name = "MPG_STG_UAT"
#db_name = "MPG_STG_DEV"
#db_name = 'MPG_EDW_UAT'

s3 = boto3.resource('s3')
secretsmanager = boto3.client("secretsmanager", region_name="us-east-2")
lambdaSession = boto3.Session()
region = lambdaSession.region_name

def make_conn():
    conn = None
    try:
        get_secret_value_response = secretsmanager.get_secret_value(
            SecretId=db_secret
        )
        secret = get_secret_value_response['SecretString']
        secret = json.loads(secret)
        db_user = secret.get('username')
        db_pass = secret.get('password')

        print("DB info:  ", db_server, db_name, db_user)
        conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER='+db_server+';DATABASE='+db_name+';UID='+db_user+';PWD='+db_pass)

        print("Successfully established connection: ", conn)
    except Exception as e:
        print("I am unable to connect to the database: ", e)
        print("Exception: {}".format(e))
    return conn


def call_rds_data_api(conn):
    rds_data = boto3.client('rds-data')
    print("sql execution started")
    sql = """
    SELECT JA.*
    FROM mpg_s2.ictJobAudit JA,
        mpg_s2.ictJobDim JD,
        mpg_s2.ictDataSrcSysDim DS
    WHERE JA.JobKey_FK = JD.JobKey_PK
        AND JD.SourceSystem_FK= DS.SourceSystem_PK
        AND DS.DataSourceName='EDW_E2'
        AND JD.jobName ='wf_MPGEDW_E1_To_E2_CaseClaimSelfServe'
        AND JA.JobStatusDescription='SUCCEEDED'
        AND JA.startTime > cast(getDate() AS Date);
          """
    cursor = conn.cursor()
    cursor.execute(sql)
    conn.commit()
    conn.close()
    print(str(response))

def lambda_handler(event, context):
    try:
        print("event: {}".format(event))
        conn = make_conn()
        conn.close()
        #call_rds_data_api(conn)
        
    except Exception as e:
        print("Failed to process Index files. Exception: {}".format(e))
        
        
        
        
        
        
        
        
        
'''




VPC
vpc-0b37fec526916ca52 (10.20.16.0/22) | vpc-us-east-2-datascience-lower-dev
Subnets

    subnet-0b4b3a8e88c9b5e66 (10.20.18.0/24) | us-east-2b, sbn-us-east-2-datascience-lower-private-dev
    subnet-0e916b045c8fd56a6 (10.20.19.0/25) | us-east-2a, sbn-us-east-2-datascience-lower-data-dev
    subnet-048e043ed6c5f867c (10.20.19.128/25) | us-east-2b, sbn-us-east-2-datascience-lower-data-dev
    subnet-07fa4565d5992fa95 (10.20.17.0/24) | us-east-2a, sbn-us-east-2-datascience-lower-private-dev

Security groups

    sg-0926753fc700e3572 (medpro-dev-ds-glue-sg) | medpro-dev-ds-glue-sg

    Inbound rules
    Outbound rules

Security group ID	Protocol	Ports	Source
sg-0926753fc700e3572	All	All	sg-0926753fc700e3572



'''