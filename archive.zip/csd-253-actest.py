import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.sql.functions import *
from awsglue.dynamicframe import DynamicFrame
from datetime import datetime, date
from pytz import timezone
import pandas as pd
import pg8000
import boto3
import json 

## @params: [JOB_NAME]
args = getResolvedOptions(sys.argv, ['JOB_NAME','raw_stage_bucket','raw_stage_database','edw_hostip','edw_hostport','edw_databasename','edw_srcschema','metarep_hostip','metarep_hostport','metarep_databasename','metarep_srcschema','metarep_secret_name','edw_secret_name'])
raw_stage_bucket = args['raw_stage_bucket']
raw_stage_database = args['raw_stage_database']
edw_hostip = args['edw_hostip']
edw_hostport = args['edw_hostport']
edw_databasename =args['edw_databasename']
edw_srcschema = args['edw_srcschema']

metarep_hostip = args['metarep_hostip']
metarep_hostport = args['metarep_hostport']
metarep_databasename = args['metarep_databasename']
metarep_srcschema = args['metarep_srcschema']
raw_tablename="stage_dim_claim"

metarep_secret_name = args['metarep_secret_name']
edw_secret_name=args['edw_secret_name']

#Extract credentials from Secrets manager
client = boto3.client("secretsmanager", region_name="us-east-2")
aurora_creds=client.get_secret_value(SecretId=metarep_secret_name)
sqlserver_creds = client.get_secret_value(SecretId=edw_secret_name)
metarep_secret=aurora_creds['SecretString']
metarep_secret=json.loads(metarep_secret)
#Retrieve Aurora Database credentials
metarep_username = metarep_secret.get('username')
metarep_password = metarep_secret.get('password')

#Retrieve SqlServer Database credentials
sqlserver_secret=sqlserver_creds['SecretString']
sqlserver_secret=json.loads(sqlserver_secret)

edw_username = sqlserver_secret.get('username')
edw_password = sqlserver_secret.get('password')

args = getResolvedOptions(sys.argv, ['JOB_NAME'])
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args['JOB_NAME'], args)

print("args: " , args)
print("db:  ", metarep_databasename)
print("username:  ",  metarep_username)
print("ip:    ", metarep_hostip)
print("port:  ", metarep_hostport)

job.commit()


'''

EXTRACT_DIM_CLAIM
IAM role
	AWSGlueServiceRole-doc-metadata
Type
	Spark
Glue version
	2.0
Python version
	3
ETL language
	python
Script location
	s3://aws-glue-scripts-613640794830-us-east-2/rnaidu/EXTRACT_DIM_CLAIM
Temporary directory
	s3://aws-glue-temporary-613640794830-us-east-2/rnaidu
Job bookmark
	Disable
Job metrics
	Disable
Continuous logging
	Disable
Server-side encryption
	Disabled


Python lib path
	s3://medpro-dev-ds-raw-data-bucket/edw/claimsrawdb/utils/pg8000.zip,s3://medpro-dev-ds-raw-data-bucket/edw/claimsrawdb/utils/scramp.zip
Jar lib path
	-
Other lib path
	-


--edw_databasename
 MPG_EDW_UAT
--edw_password
 !Zb2CK9aRVjcE!T
--metarep_hostport
 5432
--edw_secret_name
 medpro-dev-ds-edw-on-prem-sql-server
--raw_stage_database
 claimsrawdb
--metarep_username
 postgres
--metarep_srcschema
 metarep
--edw_hostport
 1433
--metarep_databasename
 cliamsdb
--metarep_hostip
 claims-metadata.cluster-cpaevzeeipsp.us-east-2.rds.amazonaws.com
--metarep_secret_name
 medpro-dev-ds-edw-rds-aurora
--metarep_password
 postgres123
--edw_srcschema
 MPG_E1
--edw_hostip
 10.2.26.54
--raw_stage_bucket
 medpro-dev-ds-raw-data-bucket
--edw_username
 svc_AWS_EDW_UAT




'''