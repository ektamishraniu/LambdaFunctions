import os
import boto3
import json
import pyodbc
pyodbc.pooling = False
import pg8000
import time
import datetime

step = boto3.client('stepfunctions')
rds_secretsmanager = boto3.client("secretsmanager", region_name="us-east-2")
rds_secret_arn = os.environ['RDS_SECRET_ARN']
rds_db_name = os.environ['DB_NAME']
rds_db_host=os.environ['RDS_Endpoint']
rds_db_port=os.environ['RDS_PORT']
edw_step_func = os.environ['EDW_STEP_FUNC']
db_secret = os.environ['EDW_DB_SECTET']
db_server = os.environ['EDW_DB_SERVER']
db_port   = os.environ['EDW_DB_PORT']
db_name   = os.environ['EDW_DB_DATABASE']
db_server = db_server + "," + db_port
aurora_log_table = os.environ['AURORA_LOG_TABLE']

ts = time.time()
timestamp = datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d %H:%M:%S')

s3 = boto3.resource('s3')
secretsmanager = boto3.client("secretsmanager", region_name="us-east-2")
lambdaSession = boto3.Session()
region = lambdaSession.region_name

def make_conn():
    conn = None
    try:
        get_secret_value_response = secretsmanager.get_secret_value(SecretId=db_secret)
        secret = get_secret_value_response['SecretString']
        secret = json.loads(secret)
        db_user = secret.get('username')
        db_pass = secret.get('password')
        conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER='+db_server+';DATABASE='+db_name+';UID='+db_user+';PWD='+db_pass)
        return conn
    except Exception as e:
        print("I am unable to connect to the database: ", e)
        return conn

def runSelectQuery(conn):
    cursor = conn.cursor()
    sql = """
    SELECT top 1 JA.* FROM mpg_s2.ictJobAudit JA, mpg_s2.ictJobDim JD,  mpg_s2.ictDataSrcSysDim DS WHERE JA.JobKey_FK = JD.JobKey_PK AND JD.SourceSystem_FK= DS.SourceSystem_PK AND DS.DataSourceName='EDW_E2' AND JD.jobName ='wf_MPGEDW_E1_To_E2_CaseClaimSelfServe' AND JA.JobStatusDescription='SUCCEEDED' AND JA.startTime > cast(getDate()-10 AS Date) order by JA.EndTime desc;
    """
    cursor.execute(sql)
    tablist = list(cursor.fetchall())    
    cursor.close()
    del cursor
    conn.close()
    return tablist



def make_conn_pg800():
    conn_pg8000 = None
    try:
        get_secret_value_response = secretsmanager.get_secret_value(SecretId=rds_secret_arn)
        secret = get_secret_value_response['SecretString']
        secret = json.loads(secret)
        rds_db_user = secret.get('username')
        rds_db_pass = secret.get('password')
        conn_pg8000 = pg8000.connect(database=rds_db_name, user=rds_db_user, password=rds_db_pass, host=rds_db_host, port=rds_db_port)
        print("Successfully established pg8000 connection")
        return conn_pg8000
    except Exception as e:
        print("I am unable to connect to pg8000: ", e)
        return conn_pg8000
   
def call_rds_data_api_to_add(jobauditkey_pk, starttime, endtime, conn_pg8000):
    try:
        cursor = conn_pg8000.cursor()
        lastupdateby = 'Batch_Job'
        Sql_insert_query = ("INSERT INTO "+ aurora_log_table +" (jobauditkey_pk, starttime, endtime, lastupdateby, lastupdatedate) VALUES(%s, %s, %s, %s, %s)") 
        record  = (jobauditkey_pk, starttime, endtime, lastupdateby, timestamp)
        cursor.execute(Sql_insert_query , record)
        conn_pg8000.commit()
    except Exception as e:
        print('Insert Failed: ', e)
    finally:
        if conn_pg8000:
            cursor.close()
            conn_pg8000.close()
            print("conn_pg8000 connection is closed")

def call_rds_data_api_select(conn_pg8000, received_jobauditkey_pk):
    print("Check for record in metarep.daily_glue_trigger_log: ", received_jobauditkey_pk)
    try:
        cursor = conn_pg8000.cursor()
        select_sql = ("select * from "+ aurora_log_table +" where jobauditkey_pk = %s")
        cursor.execute(select_sql, (received_jobauditkey_pk,))
        return cursor.rowcount
    except Exception as e:
        print('Unable to select current day Records: ', e)



def lambda_handler(event, context):
    try:
        conn_pg8000 = make_conn_pg800()
        if conn_pg8000 is None:
            print("Unable to Connect To Aurora Table, exit called: ", conn_pg8000)
            return
        
        conn = make_conn()
        if conn is None:
            print("Unable to Connect to SQL Server, exit called: ", conn_pg8000)
            return
        
        result = runSelectQuery(conn)
        print("Query Result from SQL Server:  ", result)
        if len(result):
            currentday_record_check = call_rds_data_api_select(conn_pg8000, str(result[0][0]))
            if currentday_record_check == 0:
                input = {}
                response = step.start_execution(stateMachineArn=edw_step_func, input=json.dumps(input))
                print("Done with step function medpro-dev-ds-etl invocation: ", response)
                call_rds_data_api_to_add(result[0][0], result[0][5], result[0][6], conn_pg8000)
            else:
                print("Entry is already in table metarep.daily_glue_trigger_log:  ", result[0][0], result[0][5], result[0][6])
        
        else:
            print("Data Yet not Uploaded:  ", result,  len(result))

    except Exception as e:
        print("Failed to process Lambda: {}".format(e))
        
        
        
'''
AURORA_LOG_TABLE	metarep.daily_glue_trigger_log
DB_NAME	claimsdb
EDW_DB_DATABASE	MPG_STG_UAT
EDW_DB_PORT	1433
EDW_DB_SECTET	arn:aws:secretsmanager:us-east-2:613640794830:secret:medpro-uat-ds-edw-on-prem-sql-server-x5lCXt
EDW_DB_SERVER	10.2.26.54
EDW_STEP_FUNC	arn:aws:states:us-east-2:613640794830:stateMachine:HelloworldforTest
RDS_Endpoint	medpro-dev-ds-claims-metadata-db.cluster-cpaevzeeipsp.us-east-2.rds.amazonaws.com
RDS_PORT	5432
RDS_SECRET_ARN	arn:aws:secretsmanager:us-east-2:613640794830:secret:medpro-dev-ds-edw-rds-aurora-StaJ2k


START RequestId: eff42d38-ebac-4363-b27f-02ba7f2f7d6d Version: $LATEST
Successfully established pg8000 connection
Query Result from SQL Server:   [(20690, 2241, 22, 320, 12.967, datetime.datetime(2021, 4, 20, 11, 5, 8), datetime.datetime(2021, 4, 20, 11, 18, 6), None, None, None, None, None, '25756', '1', 'SUCCEEDED')]
Check for record in metarep.daily_glue_trigger_log:  20690
Entry is already in table metarep.daily_glue_trigger_log:   20690 2021-04-20 11:05:08 2021-04-20 11:18:06
END RequestId: eff42d38-ebac-4363-b27f-02ba7f2f7d6d
REPORT RequestId: eff42d38-ebac-4363-b27f-02ba7f2f7d6d	Duration: 583.80 ms	Billed Duration: 584 ms	Memory Size: 1024 MB	Max Memory Used: 94 MB	Init Duration: 574.59 ms
'''