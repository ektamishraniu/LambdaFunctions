edw_databasename   MPG_EDW_UAT
edw_srcschema      MPG_E1
EventName  --- Its a alpha numeric number  E1635443 ,  E1477722 in dimCase

medpro-dev-ds-metarepdb

SELECT TOP (1000) 
[Case_PK]  ("case_pk", "long", "case_pk", "long")
[Case_NK]  ("case_nk", "long", "case_nk", "long")
[CaseNumber]  "casenumber", "string", "casenumber", "string"
[CaseName]  ("casename", "string", "casename", "string"
[EventName] ("eventname", "string", "eventname", "string"
[RelatedCaseInCase]  ("relatedcaseincase", "string", "relatedcaseincase", "string")
[NumberOfClaims]  ("numberofclaims", "short", "numberofclaims", "short")
[CaseLOB]  ("caselob", "string", "caselob", "string")
[CaseFirstOpenDate]  "casefirstopendate", "timestamp", "casefirstopendate", "timestamp"
[CaseLatestReopenDate] "caselatestreopendate", "timestamp", "caselatestreopendate", "timestamp"
[CaseLatestCloseDate]  "caselatestclosedate", "timestamp", "caselatestclosedate", "timestamp"
[LossReserveDescription] "lossreservedescription", "string", "lossreservedescription", "string"
[LossReserveEffectiveDate] "lossreserveeffectivedate", "timestamp", "lossreserveeffectivedate", "timestamp"
[LossReserveSetBy]  ("lossreservesetby", "string", "lossreservesetby", "string")
[ReserveAdequateDate]  "reserveadequatedate", "timestamp", "reserveadequatedate", "timestamp"
[ReserveAdequateTimelessness]  "reserveadequatetimelessness", "short", "reserveadequatetimelessness", "short"
[ReserveAnticipateZeroDate]   "reserveanticipatezerodate", "timestamp", "reserveanticipatezerodate", "timestamp"
[ReserveAnticipateZeroTimelessness]  "reserveanticipatezerotimelessness", "short", "reserveanticipatezerotimelessness", "short")
[ReserveFinalPostedDate]             "reservefinalposteddate", "timestamp", "reservefinalposteddate"
[ReserveFinalPostedTimelessness]  ("reservefinalpostedtimelessness", "short", "reservefinalpostedtimelessness", "short")
[Court]  ("court", "string", "court", "string")
[PatientAgeAtLoss]  "patientageatloss", "string", "patientageatloss", "string"
[CaseCurrentStatus]  ("casecurrentstatus", "string", "casecurrentstatus", "string")
[CaseCurrentType]  ("casecurrenttype", "string", "casecurrenttype", "string")
[SourceSystem]     ("sourcesystem", "string", "sourcesystem", "string")
[CreateDate]       ("createdate", "timestamp", "createdate", "timestamp")
[CreateBy]         ("createby", "string", "createby", "string")
[EndDate]          ("enddate", "timestamp", "enddate", "timestamp")
[CurrentRecordFlag]  ("currentrecordflag", "int", "currentrecordflag", "int")
[LastUpdateDate]   "lastupdatedate", "timestamp", "lastupdatedate", "timestamp"
[LastUpdateBy]     "lastupdateby", "string", "lastupdateby", "string"
[BatchId]          ("batchid", "string", "batchid", "string")
  FROM [MPG_EDW_UAT].[MPG_E1].[edwCaseDim]
  
  
SELECT TOP (1000) [Claim_PK]
[Claim_NK]
[ClaimNumber]
[Case_FK]
[Case_NK]
[Policy_FK]
[Policy_NK]
[Risk_FK]
[Risk_NK]
[Coverage_FK]
[Coverage_NK]
[LegacyCaseNumber]
[LegacyCaseNumber2]
[LossDescription]
[PrimaryClaimFlag]
[ClaimLOB]
[TreatmentDate]
[ReportDate]
[ServiceDate]
[ClaimCurrentStatus]
[ClaimCurrentType]
[ClaimFirstOpenDate]
[ClaimLatestReopenDate]
[ClaimLatestCloseDate]
[Condition]
[Treatement]
[Allegation]
[Result]
[ClaimCity]
[ClaimCounty]
[ClaimState]
[SpecialTracking]
[ClaimFinalDisposition]
[ClaimFinalDispositionCode]
[ClaimFinalDispositionGroup]
[ClaimFinalDispositionDate]
[AgentOfInsuredFlag]
[IndemnityPaid]
[LossType]
[LossSubType]
[GLLossType]
[ConsentFlag]
[PunititiveDamagesFlag]
[ClaimCreateDate]
[ClaimCreateBy]
[ClaimUpdateDate]
[ClaimUpdateBy]
[SourceSystem]
[CreateDate]
[CreateBy]
[EndDate]
[CurrentRecordFlag]
[LastUpdateDate]
[LastUpdateBy]
[BatchId]
  FROM [MPG_EDW_UAT].[MPG_E1].[edwClaimDim]