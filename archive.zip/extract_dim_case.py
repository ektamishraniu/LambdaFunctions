import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.sql.functions import *
from awsglue.dynamicframe import DynamicFrame
from datetime import datetime, date
from pytz import timezone
import pandas as pd
import pg8000
import boto3
import json

## @params: [JOB_NAME]
args = getResolvedOptions(sys.argv, ['JOB_NAME','raw_stage_bucket','raw_stage_database','edw_hostip','edw_hostport','edw_databasename','edw_srcschema','metarep_hostip','metarep_hostport','metarep_databasename','metarep_srcschema','metarep_secret_name','edw_secret_name'])
raw_stage_bucket = args['raw_stage_bucket']
raw_stage_database = args['raw_stage_database']
edw_hostip = args['edw_hostip']
edw_hostport = args['edw_hostport']
edw_databasename =args['edw_databasename']
edw_srcschema = args['edw_srcschema']

metarep_hostip = args['metarep_hostip']
metarep_hostport = args['metarep_hostport']
metarep_databasename = args['metarep_databasename']
metarep_srcschema = args['metarep_srcschema']
raw_tablename="stage_dim_case"

metarep_secret_name = args['metarep_secret_name']
edw_secret_name=args['edw_secret_name']

#Extract credentials from Secrets manager
client = boto3.client("secretsmanager", region_name="us-east-2")
aurora_creds=client.get_secret_value(SecretId=metarep_secret_name)
sqlserver_creds = client.get_secret_value(SecretId=edw_secret_name)
metarep_secret=aurora_creds['SecretString']
metarep_secret=json.loads(metarep_secret)
#Retrieve Aurora Database credentials
metarep_username = metarep_secret.get('username')
metarep_password = metarep_secret.get('password')

#Retrieve SqlServer Database credentials
sqlserver_secret=sqlserver_creds['SecretString']
sqlserver_secret=json.loads(sqlserver_secret)

edw_username = sqlserver_secret.get('username')
edw_password = sqlserver_secret.get('password')

args = getResolvedOptions(sys.argv, ['JOB_NAME'])
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args['JOB_NAME'], args)

#Create Connection to extract lastcreatetimestamp from etl control table
query_conn = pg8000.connect(
    database=metarep_databasename,
    user=metarep_username,
    password=metarep_password,
    host=metarep_hostip,
    port=metarep_hostport
)
read_control_table = """
select last_extract_time
    from metarep.etl_extract_state
    where table_name='stage_dim_case'
    group by last_extract_time
"""
cur = query_conn.cursor()
cur.execute(read_control_table)
last_extract_time=str(cur.fetchone()[0])
cur.close()
query_conn.close()
job_start_time=datetime.now().strftime('%Y-%m-%d %H:%M:%S')
#Extract data from SQL server
extract_df = glueContext.read.format("jdbc").option("url","jdbc:sqlserver://"+edw_hostip+":"+edw_hostport+";databaseName="+edw_databasename+";").option("user",edw_username).option("password",edw_password).option("dbtable","(select * from "+edw_srcschema+".edwcasedim where ( createdate>'"+last_extract_time+"' or lastupdatedate>'"+last_extract_time+"' )) as edwcasedim").option("driver","com.microsoft.sqlserver.jdbc.SQLServerDriver").load()
init_dynamicframe = DynamicFrame.fromDF(extract_df, glueContext, "init_dynamicframe")
applymapping1 = ApplyMapping.apply(frame = init_dynamicframe, mappings = [("case_pk", "long", "case_pk", "long"), ("casecurrentstatus", "string", "casecurrentstatus", "string"), ("lastupdateby", "string", "lastupdateby", "string"), ("caselob", "string", "caselob", "string"), ("case_nk", "long", "case_nk", "long"), ("reserveanticipatezerotimelessness", "short", "reserveanticipatezerotimelessness", "short"), ("caselatestclosedate", "timestamp", "caselatestclosedate", "timestamp"), ("createby", "string", "createby", "string"), ("casecurrenttype", "string", "casecurrenttype", "string"), ("relatedcaseincase", "string", "relatedcaseincase", "string"), ("createdate", "timestamp", "createdate", "timestamp"), ("court", "string", "court", "string"), ("currentrecordflag", "int", "currentrecordflag", "int"), ("caselatestreopendate", "timestamp", "caselatestreopendate", "timestamp"), ("reserveadequatedate", "timestamp", "reserveadequatedate", "timestamp"), ("casenumber", "string", "casenumber", "string"), ("lossreserveeffectivedate", "timestamp", "lossreserveeffectivedate", "timestamp"), ("reserveadequatetimelessness", "short", "reserveadequatetimelessness", "short"), ("reserveanticipatezerodate", "timestamp", "reserveanticipatezerodate", "timestamp"), ("casename", "string", "casename", "string"), ("batchid", "string", "batchid", "string"), ("patientageatloss", "string", "patientageatloss", "string"), ("casefirstopendate", "timestamp", "casefirstopendate", "timestamp"), ("reservefinalposteddate", "timestamp", "reservefinalposteddate", "timestamp"), ("eventname", "string", "eventname", "string"), ("lossreservesetby", "string", "lossreservesetby", "string"), ("enddate", "timestamp", "enddate", "timestamp"), ("numberofclaims", "short", "numberofclaims", "short"), ("lossreservedescription", "string", "lossreservedescription", "string"), ("reservefinalpostedtimelessness", "short", "reservefinalpostedtimelessness", "short"), ("sourcesystem", "string", "sourcesystem", "string"), ("lastupdatedate", "timestamp", "lastupdatedate", "timestamp")], transformation_ctx = "applymapping1")
resolvechoice2 = ResolveChoice.apply(frame = applymapping1, choice = "make_struct", transformation_ctx = "resolvechoice2")
dropnullfields3 = DropNullFields.apply(frame = resolvechoice2, transformation_ctx = "dropnullfields3")
#Extract max create timestamp from dataframe
temp_df=applymapping1.toDF().createOrReplaceTempView("stage_df")
max_extract_time_sf = spark.sql("SELECT max(maxdate)  from (select COALESCE(max(createdate),'"+last_extract_time+"' ) as maxdate FROM   stage_df union select COALESCE(max(lastupdatedate),'"+last_extract_time+"' ) as maxdate FROM   stage_df)a")
 
print(max_extract_time_sf.first()[0])
print('run time is ' +str(job_start_time) )
max_extract_time=str(max_extract_time_sf.first()[0])

if max_extract_time==last_extract_time:
    print('true')
else:
    print('false')

#Copy/Sink the data to S3
datasink4 = glueContext.write_dynamic_frame.from_options(frame = applymapping1, connection_type = "s3", connection_options = {"path": "s3://"+raw_stage_bucket+"/edw/"+raw_stage_database+"/"+raw_tablename+"/incremental_createtimestamp="+job_start_time+"/"}, format = "parquet", transformation_ctx = "datasink4")

#Connect to Aurora postgres db
config_port = 5432
update_conn = pg8000.connect(
    database=metarep_databasename,
    user=metarep_username,
    password=metarep_password,
    host=metarep_hostip,
    port=metarep_hostport
)
#Update extract flag=0 to indicate the extraction was completed successfully and
#set load_flag=0 to indicate the load is still pending for next glue job to pickup data from s3 bucket

update_control_table = "update metarep.etl_extract_state set job_start_time='"+job_start_time+"',extract_flag=1, load_flag=0 where table_name='stage_dim_case';"
cur = update_conn.cursor()
cur.execute(update_control_table)
update_conn.commit()
cur.close()
update_conn.close()

job.commit()