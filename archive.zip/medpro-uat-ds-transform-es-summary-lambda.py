import os, re
import io
import boto3
import botocore
import csv
from pathlib import Path, PurePath
import json, time
from datetime import datetime
import pg8000
# Update your cluster and secret ARNs
#cluster_arn = 'arn:aws:rds:us-east-2:613640794830:cluster:claims-metadata'
#secret_arn = 'arn:aws:secretsmanager:us-east-2:613640794830:secret:rds-db-credentials/cluster-W5WP6RXJ7P6EOLGQ5FMZM7JXBI/postgres-fGrIb0'

db_secret=os.environ['RDS_SECRET_ARN']
db_name=os.environ['RDS_DB_NAME']
db_host=os.environ['RDS_Endpoint']
db_port=os.environ['RDS_PORT']


s3 = boto3.resource('s3')
secretsmanager = boto3.client("secretsmanager", region_name="us-east-2")
lambdaSession = boto3.Session()
region = lambdaSession.region_name

def make_conn():
    conn = None
    try:
        get_secret_value_response = secretsmanager.get_secret_value(
            SecretId=db_secret
        )
        secret = get_secret_value_response['SecretString']
        secret = json.loads(secret)
        db_user = secret.get('username')
        db_pass = secret.get('password')
        #conn = psycopg2.connect("dbname='%s' user='%s' host='%s' password='%s'" % (db_name, db_user, db_host, db_pass))
        conn = pg8000.connect(
            database=db_name,
            user=db_user,
            password=db_pass,
            host=db_host,
            port=db_port
        )
        print("Successfully established connection")
    except:
        print("I am unable to connect to the database")
    return conn


def call_rds_data_api(conn):
    rds_data = boto3.client('rds-data')
    print("sql execution started")
    sql = """
           TRUNCATE metarep.ES_META_SUMMARY_stage1;
           TRUNCATE metarep.ES_META_SUMMARY_stage2;
             INSERT INTO metarep.ES_META_SUMMARY_stage1
                        select dc.casenumber, dc.eventname ,claimlob,caseclaimstatus,claimcounty,claimcity,claimstate,claimfinaldispositioncode,
     sum(claimtransactionamount) ,
     defendant.fullname  as defendant,
    filemanager.fullname   as filemanager,
     patient.fullname as patient,
    PLANTIFFATTORNEY.fullname  as plantiffattorney,
    condition,
     now()::timestamp(0) as createdate,
    now()::timestamp(0) as lastupdatedate
     from  metarep.dim_case dc
     join(
     select    dcm.case_nk ,
        string_agg(dcm.claimlob,',') as claimlob,
      string_agg(dcs.caseclaimstatus,',')   as caseclaimstatus,
     string_agg( dcm.claimcounty ,',')  as claimcounty,
       string_agg(dcm.claimcity,',')  as claimcity,
       string_agg( dcm.claimstate,',') as claimstate,
    string_agg( dcm.claimfinaldispositioncode,',')  as claimfinaldispositioncode ,
     sum(ftc.claimtransactionamount ) as claimtransactionamount ,
         string_agg(dcm.condition ,',') as condition
                          from  metarep.dim_claim dcm
                            JOIN metarep.caseclaimstatus dcs
                              ON (dcs.statusenddate = '3000-01-01 00:00:00'
                                 AND dcs.caseclaim_fk = dcm.claim_pk)
                               LEFT JOIN  (
                             select claim_fk,claim_nk, sum(claimtransactionamount) claimtransactionamount from metarep.fact_txn_claim where currentrecordflag
                             =1 and claimtransactiontype ='Loss Reserve'
                             group by claim_fk,claim_nk) ftc
                            on ftc.claim_fk=dcs.caseclaim_fk
                     where dcm.currentrecordflag=1
                             group by dcm.case_nk
       )dcm
       on dc.case_nk=dcm.case_nk
           left join
                    (
                    select dpr.SourceTable_NK,
                    string_agg( dsp.fullname,',') as fullname
                    from METAREP.DIM_PARTYROLE dpr
                    LEFT JOIN  metarep.dim_sourceparty dsp
                    on dsp.SourceParty_nK=dpr.SourceParty_nk
                    where  dpr.PartyRoleCode ='CLMINSURED'
                    and dpr.currentrecordflag=1
                    and dsp.currentrecordflag=1
                    GROUP BY  dpr.SourceTable_NK
                    ) defendant on  dc.Case_nk=defendant.SourceTable_NK
                    left join
                    (
                    select dpr.SourceTable_NK,
                     string_agg(dsp.fullname,',') as fullname
                    from METAREP.DIM_PARTYROLE dpr
                    LEFT JOIN  metarep.dim_sourceparty dsp
                    on dsp.SourceParty_nK=dpr.SourceParty_nk
                    where  dpr.PartyRoleCode ='EXAMINER'
                    and dpr.currentrecordflag=1
                    and dsp.currentrecordflag=1
                    GROUP BY  dpr.SourceTable_NK
                    ) filemanager on
                     dc.case_nk=filemanager.SourceTable_NK
                    left join
                    (
                    select  dpr.SourceTable_NK,
                        string_agg(dsp.fullname,',') as fullname
                    from METAREP.DIM_PARTYROLE dpr
                    LEFT JOIN  metarep.dim_sourceparty dsp
                    on dsp.SourceParty_nK=dpr.SourceParty_nk
                    where  dpr.PartyRoleCode ='CLAIMANT'
                    and dpr.currentrecordflag=1
                    and dsp.currentrecordflag=1
                    GROUP BY   dpr.SourceTable_NK
                    ) patient on   dc.Case_nk=patient.SourceTable_NK
                    left join
                    (
                    select  dpr.SourceTable_NK,
                        string_agg(dsp.fullname,',') as fullname
                    from METAREP.DIM_PARTYROLE dpr
                    LEFT JOIN  metarep.dim_sourceparty dsp
                    on dsp.SourceParty_nk=dpr.SourceParty_nk
                    where  dpr.PartyRoleCode ='PATTORNEY'
                    and dpr.currentrecordflag=1
                    and dsp.currentrecordflag=1
                    GROUP BY  dpr.SourceTable_NK
                    ) PLANTIFFATTORNEY on  dc.Case_nk=PLANTIFFATTORNEY.SourceTable_NK
                    where dc.currentrecordflag=1
                       group by dc.casenumber, dc.eventname,
                 claimlob,
                   caseclaimstatus     ,
                         claimcounty   ,
                               claimcity  ,
                                claimstate  ,
                                 claimfinaldispositioncode ,
                                    defendant.fullname   ,
                                    filemanager.fullname   ,
                                    patient.fullname  ,
                                    PLANTIFFATTORNEY.fullname   ,
                               condition
                ;
          """
    sql2 = """ Insert into metarep.ES_META_SUMMARY_Stage2
                     select stage1.* ,'I' as INSUPDFlag
                     from metarep.ES_META_SUMMARY_Stage1 stage1
                     left join metarep.ES_META_SUMMARY  final
                        on stage1.casenumber=final.casenumber
                        where final.casenumber is null;
            """
    sql3 = """
             Insert into metarep.ES_META_SUMMARY_Stage2
                     select stage.*, 'U' as INSUPDFlag
                     from metarep.ES_META_SUMMARY_Stage1 stage
                     inner join  metarep.es_meta_summary final
                      on stage.casenumber=final.casenumber
                    and  ( coalesce(stage.claimlob,'0')<>coalesce(final.claimlob,'0') or
                     coalesce(stage.caseclaimstatus,'0')<>coalesce(final.caseclaimstatus,'0') or
                     coalesce(stage.claimcounty,'0')<> coalesce(final.claimcounty,'0') or
                     coalesce(stage.claimcity,'0')<>coalesce(final.claimcity,'0')  or
                     coalesce(stage.claimstate,'0')<> coalesce(final.claimstate,'0') or
                     coalesce(stage.claimfinaldispositioncode,'0')<> coalesce(final.claimfinaldispositioncode,'0') or
                     coalesce(stage.claimtransactionamount,'0')<> coalesce(final.claimtransactionamount ,'0')or
                     coalesce(stage.defendant,'0')<> coalesce(final.defendant,'0') or
                     coalesce(stage.filemanager,'0')<> coalesce(final.filemanager,'0') or
                     coalesce(stage.patient,'0')<> coalesce(final.patient,'0') or
                     coalesce(stage.plantiffattorney,'0')<> coalesce(final.plantiffattorney,'0') or
                     coalesce(stage.condition,'0')<> coalesce(final.condition,'0'));
           """
    new_records = """
             insert into metarep.es_meta_summary (casenumber, eventname, 
                claimlob,
                caseclaimstatus,
                claimcounty,
                claimcity,
                claimstate,
                claimfinaldispositioncode,
                claimtransactionamount,
                defendant,
                filemanager,
                patient,
                plantiffattorney,
                condition,
                createdate,
                lastupdatedate)
                select
                casenumber,
                eventname,
                claimlob,
                caseclaimstatus,
                claimcounty,
                claimcity,
                claimstate,
                claimfinaldispositioncode,
                claimtransactionamount,
                defendant,
                filemanager,
                patient,
                plantiffattorney,
                condition,
                createdate,
                lastupdatedate from metarep.es_meta_summary_stage2 where INSUPDFlag='I';
                """
    update_records = """
             update metarep.es_meta_summary
             set eventname=ES_META_SUMMARY_Stage2.eventname ,
                 claimlob=ES_META_SUMMARY_Stage2.claimlob ,
                 caseclaimstatus=ES_META_SUMMARY_Stage2.caseclaimstatus ,
                 claimcounty=ES_META_SUMMARY_Stage2.claimcounty ,
                 claimcity=ES_META_SUMMARY_Stage2.claimcity ,
                 claimstate=ES_META_SUMMARY_Stage2.claimstate ,
                 claimfinaldispositioncode=ES_META_SUMMARY_Stage2.claimfinaldispositioncode ,
                 claimtransactionamount=ES_META_SUMMARY_Stage2.claimtransactionamount ,
                 defendant=ES_META_SUMMARY_Stage2.defendant ,
                 filemanager=ES_META_SUMMARY_Stage2.filemanager ,
                 patient=ES_META_SUMMARY_Stage2.patient ,
                 plantiffattorney=ES_META_SUMMARY_Stage2.plantiffattorney ,
                 condition=ES_META_SUMMARY_Stage2.condition,
                 lastupdatedate=ES_META_SUMMARY_Stage2.lastupdatedate
            from metarep.ES_META_SUMMARY_Stage2
             where es_meta_summary.casenumber=ES_META_SUMMARY_Stage2.casenumber and ES_META_SUMMARY_Stage2.INSUPDFlag='U';
            """
    cursor = conn.cursor()
    cursor.execute(sql)
    conn.commit()
    print("sql 1 is successful")
    cursor.execute(sql2)
    conn.commit()
    print("sql 2 is successful")
    cursor.execute(sql3)
    conn.commit()
    print("sql 3 is successful")
    cursor.execute(new_records)
    conn.commit()
    print("sql 4 is successful")
    cursor.execute(update_records)
    conn.commit()
    print("sql 5 is successful")
    conn.close()
    #print(str(response))

def lambda_handler(event, context):

    try:
        print("event: {}".format(event))
        conn = make_conn()
        call_rds_data_api(conn)
    except Exception as e:
        print("Failed to process Index files. Exception: {}".format(e))
        time.sleep( 120 )