import json
import boto3
import os
from botocore.exceptions import ClientError
from urllib.parse import unquote_plus
from elasticsearch import Elasticsearch, RequestsHttpConnection
from pathlib import Path, PurePath
from datetime import datetime, timedelta
from pytz import timezone
import re
from requests_aws4auth import AWS4Auth

ET = timezone('US/Eastern')
fmt = '%Y-%m-%d %H:%M:%S %Z'
today = datetime.now(ET).strftime('%Y-%m-%d')

s3 = boto3.resource('s3')
dest_s3_bucket = os.environ['ERROR_FILES_BUCKET']

lambdaSession = boto3.Session()
region = lambdaSession.region_name
host=os.environ['ELASTICSEARCH_ENDPOINT']
credentials = lambdaSession.get_credentials()
awsauth = AWS4Auth(credentials.access_key, credentials.secret_key, region, 'es', session_token=credentials.token)

indexDoc = {
    "mappings" : {
            "properties" : {
          "documentCreatedOn" : {
            "type" : "date",
            "format" : "dateOptionalTime"
          },
          "documentCompletedOn" : {
            "type" : "date",
            "format" : "dateOptionalTime"
          },
          "fileName" : {
            "type" : "text"
          },
          "stepFunctionId" : {
            "type" : "text"
          },
          "documentId" : {
            "type" : "text"
          },
          "status" : {
            "type" : "text"
          },
          "bucketName" : {
            "type" : "text"
          },
          "objectName" : {
            "type" : "text"
          },
          "errorType" : {
            "type" : "text"
          }
        }
    },
    "settings" : {
        "number_of_shards": 1,
        "number_of_replicas": 0
      }
    }

def createIndex(esClient):
    try:
        res = esClient.indices.exists('doc_extraction_status')
        if res is False:
            esClient.indices.create('doc_extraction_status', body=indexDoc)
        return 1
    except Exception as E:
        print("Unable to Create Index {0}".format("doc_extraction_status"))
        print(E)
        exit(4)


class ElasticsearchIndexCreatorForStatus: 

    def __init__(self, srcBucketName, objectName, stepFuncExecId):
        self.bucketName = srcBucketName
        self.srcFilePath = objectName
        self.objectName = PurePath(objectName).name
        self.stepFuncExecId = stepFuncExecId

    def _getIndexId(self, ObjName):
        match = re.search('\d+.msg-attachment-(.+?)-(.+?)\..*', ObjName)
        if match:
            attachment_number = match.group(1)
            attachment_name = match.group(2)
            indexId = str(self._getDocId(ObjName)) + attachment_name + str(attachment_number)
        else:
            indexId = self._getDocId(ObjName)
        return indexId
    
    def _getDocId(self, ObjName):
        while "." in ObjName:
            ObjName = Path(ObjName).stem
        return ObjName
    
    def _addToESIndex(self, indexId, document):
        es = Elasticsearch(
        hosts = [{'host': host, 'port':443}],
        use_ssl = True,
        verify_certs = True,
        http_auth=awsauth,
        connection_class = RequestsHttpConnection
        )
       # createIndex(es)

        es.index(index="doc_extraction_status", id=indexId, body=document)
    
    def _updateESIndex(self, indexId, document):

        es = Elasticsearch(
        hosts = [{'host': host, 'port':443}],
        use_ssl = True,
        verify_certs = True,
        http_auth=awsauth,
        connection_class = RequestsHttpConnection
        )

        es.update(index="doc_extraction_status",id=indexId, body=document)
    
    def _copyToFailedS3(self, srcFilePath,sourceBucket):
        try:
            copy_source = {
                'Bucket': sourceBucket,
                'Key': srcFilePath
            }
            key = "extraction-failed-files/{}/{}".format(today, PurePath(srcFilePath).name)
            destbucket = s3.Bucket(dest_s3_bucket)
            destbucket.copy(copy_source, key)
            print('{} transferred to destination bucket'.format(key))
            return key

        except Exception as e:
            print(e)
            print('Error while copying the object {} to bucket {}. '.format(srcFilePath, dest_s3_bucket))
            raise e

    def markDocumentComplete(self):
        indexId = self._getIndexId(self.objectName)
        document = {'doc': {
                'status': "COMPLETE",
                'documentCompletedOn': datetime.now(ET),
                'errorType': ""
                }}
        self._updateESIndex(indexId, document)
        try:
          destKey = "extraction-failed-files/{}/{}".format(today, self.objectName)
          destObj = s3.Object(dest_s3_bucket, destKey)
          destObj.delete() 
        except ClientError as e:
          print(e)
    
    def markDocumentFailed(self, errorType):
        indexId = self._getIndexId(self.objectName)
        failed_s3_job_loc = self._copyToFailedS3(self.srcFilePath, self.bucketName )
        print('{}'.format(failed_s3_job_loc))
        document = {'doc': {
                'status': "FAILED",
                'documentCompletedOn': datetime.now(ET),
                'stepFunctionId': '{}'.format(self.stepFuncExecId),
                'errorType': errorType
                }}
        self._updateESIndex(indexId, document)
    
    def markDocumentInProgress(self):
        documentId = self._getDocId(self.objectName)
        indexId = self._getIndexId(self.objectName)
        document = {
                'fileName': '{}'.format(self.objectName),
                'documentId': '{}'.format(documentId),
                'stepFunctionId': '{}'.format(self.stepFuncExecId),
                'status': "IN_PROGRESS",
                'bucketName': '{}'.format(self.bucketName),
                'objectName': '{}'.format(self.srcFilePath),
                'documentCreatedOn': datetime.now(ET)
                }
        self._addToESIndex(indexId, document)
       
    def markDocumentAsInProgress(self, state_machine_id):
        documentId = self._getDocId(self.objectName)
        indexId = self._getIndexId(self.objectName)
        document = {
                'fileName': '{}'.format(self.objectName),
                'documentId': '{}'.format(documentId),
                "stepFunctionId": "{}".format(state_machine_id),
                'status': "IN_PROGRESS",
                'documentCreatedOn': datetime.now(ET)
                }
        self._addToESIndex(indexId, document)



            
